extends Node3D

# Olive & Stone — a colony-simulation prototype rooted in Palestine.
# Geographic layout is a simplified Haifa-area blockout, not a surveyed DEM.
# Map orientation: Mediterranean west (left), Carmel ridge inland (east/right).

const GRID := 48
const TILE_SIZE := 75.0 # 3.6 km north-south; compact mobile play area
const STARTING_POPULATION := 15
const SAVE_PATH := "user://olive_stone_save.json"
const SEA_COLOR := Color("#477f91")

var resources := {"Food": 150.0, "Water": 180.0, "Wood": 100.0, "Stone": 85.0, "Scrap": 45.0}
var population := STARTING_POPULATION
var day := 1
var morale := 76.0
var health := 100.0
var selected_building := ""
var buildings: Array[Dictionary] = []
var survivors: Array[Dictionary] = []
var hud: CanvasLayer
var status_label: Label
var resource_label: Label
var population_label: Label
var day_label: Label
var camera: Camera3D
var terrain_root: Node3D
var building_root: Node3D
var rng := RandomNumberGenerator.new()
var camera_target := Vector3.ZERO
var mouse_dragging := false
var touch_dragging := false
var pointer_start := Vector2.ZERO
var last_pointer := Vector2.ZERO
var touch_moved := false
var tick_timer: Timer

const BUILDINGS := {
	"Shelter": {"cost": {"Wood": 18.0, "Stone": 8.0}, "color": Color("#c6b394"), "description": "Housing +5"},
	"Well": {"cost": {"Stone": 22.0, "Wood": 8.0}, "color": Color("#5797ad"), "description": "Water +28/day"},
	"Farm": {"cost": {"Wood": 12.0, "Stone": 5.0}, "color": Color("#779b55"), "description": "Food +24/day"},
	"Workshop": {"cost": {"Wood": 18.0, "Stone": 12.0, "Scrap": 6.0}, "color": Color("#8c8176"), "description": "Wood +3/day"}
}

func _ready() -> void:
	rng.randomize()
	_build_world()
	_build_camera()
	_build_lighting()
	_build_ui()
	_create_survivors()
	_refresh_ui()
	tick_timer = Timer.new()
	tick_timer.wait_time = 12.0
	tick_timer.timeout.connect(_advance_day)
	add_child(tick_timer)
	tick_timer.start()
	_set_status("Haifa coast and Carmel foothills — a story rooted in Palestine.")

# Stylized terrain profile informed by Haifa's coastal plain and Carmel relief.
# A later DEM import can replace this function without changing simulation code.
func _terrain_height(gx: float, gz: float) -> float:
	var east := gx / float(GRID - 1)
	var north_south := gz / float(GRID - 1)
	# Coastal plain, rising Carmel escarpment and inland shoulder.
	var escarpment_center := 0.58 + 0.045 * sin((north_south * 1.2 + 0.12) * TAU)
	var rise := 430.0 / (1.0 + exp(-19.0 * (east - escarpment_center)))
	var ridge_center := 0.77 + 0.025 * sin(north_south * TAU * 1.4)
	var ridge := 75.0 * exp(-pow((east - ridge_center) / 0.075, 2.0))
	# Wadi corridors cut across the slope; coastal plain stays relatively level.
	var wadi_a := 32.0 * exp(-pow((east - (0.47 + 0.035 * sin(north_south * 8.0))) / 0.028, 2.0))
	var wadi_b := 24.0 * exp(-pow((east - (0.68 + 0.025 * cos(north_south * 7.0))) / 0.025, 2.0))
	var local_relief := 9.0 * sin(gx * 0.39) * cos(gz * 0.31) + 5.0 * sin(gz * 0.67)
	return maxf(3.0, rise + ridge + local_relief - wadi_a - wadi_b)

func _coastline_x(gz: float) -> float:
	# Irregular bay/shoreline line: the coastline is on the western side.
	return 5.2 + 1.4 * sin(gz * 0.13) + 0.65 * sin(gz * 0.31 + 1.0)

func _is_land(gx: int, gz: int) -> bool:
	return gx >= 0 and gx < GRID and gz >= 0 and gz < GRID and float(gx) >= _coastline_x(float(gz))

func _build_world() -> void:
	terrain_root = Node3D.new()
	terrain_root.name = "HaifaTerrain"
	add_child(terrain_root)
	building_root = Node3D.new()
	building_root.name = "SettlementBuildings"
	add_child(building_root)
	_build_sea()
	_build_land_mesh()
	_add_olive_groves()
	_add_geographic_labels()

func _build_sea() -> void:
	var sea := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(TILE_SIZE * 16.0, TILE_SIZE * GRID * 1.1)
	sea.mesh = plane
	sea.position = Vector3(-TILE_SIZE * 15.0, -1.0, 0.0)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = SEA_COLOR
	mat.roughness = 0.32
	mat.metallic = 0.05
	sea.material_override = mat
	terrain_root.add_child(sea)

func _build_land_mesh() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for x in range(GRID - 1):
		for z in range(GRID - 1):
			var center_x := x + 0.5
			if center_x < _coastline_x(float(z) + 0.5):
				continue
			var p00 := _grid_vertex(x, z)
			var p10 := _grid_vertex(x + 1, z)
			var p01 := _grid_vertex(x, z + 1)
			var p11 := _grid_vertex(x + 1, z + 1)
			_add_terrain_triangle(st, p00, p01, p10, x, z)
			_add_terrain_triangle(st, p10, p01, p11, x, z)
	st.generate_normals()
	var land_mesh := st.commit()
	var surface := MeshInstance3D.new()
	surface.name = "TerrainSurface"
	surface.mesh = land_mesh
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 1.0
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	surface.material_override = mat
	terrain_root.add_child(surface)
	var body := StaticBody3D.new()
	body.name = "TerrainCollision"
	var collision := CollisionShape3D.new()
	collision.shape = land_mesh.create_trimesh_shape()
	body.add_child(collision)
	terrain_root.add_child(body)

func _grid_vertex(gx: int, gz: int) -> Vector3:
	var x := (float(gx) - GRID / 2.0 + 0.5) * TILE_SIZE
	var z := (float(gz) - GRID / 2.0 + 0.5) * TILE_SIZE
	return Vector3(x, _terrain_height(float(gx), float(gz)), z)

func _add_terrain_triangle(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, gx: int, gz: int) -> void:
	st.set_color(_terrain_color((a.y + b.y + c.y) / 3.0, gx, gz))
	st.add_vertex(a)
	st.add_vertex(b)
	st.add_vertex(c)

func _terrain_color(elevation: float, gx: int, gz: int) -> Color:
	# Coastal sand/soil, olive scrub on lower slopes, pale limestone on the ridge.
	if elevation > 350.0:
		return Color("#b5ad99") if (gx + gz) % 4 else Color("#a49c89")
	if elevation > 190.0:
		return Color("#858b68") if (gx * 3 + gz) % 5 else Color("#a29b78")
	if elevation > 65.0:
		return Color("#899064") if (gx + gz) % 3 else Color("#a39a70")
	return Color("#b6a27b") if (gx + gz) % 4 else Color("#c0ad85")

func _add_olive_groves() -> void:
	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius = 1.0
	trunk_mesh.bottom_radius = 1.5
	trunk_mesh.height = 9.0
	var crown_mesh := SphereMesh.new()
	crown_mesh.radius = 7.0
	crown_mesh.height = 11.0
	var trunk_mat := StandardMaterial3D.new()
	trunk_mat.albedo_color = Color("#66513a")
	var crown_mat := StandardMaterial3D.new()
	crown_mat.albedo_color = Color("#66734a")
	for i in range(105):
		var gx := rng.randi_range(13, GRID - 2)
		var gz := rng.randi_range(0, GRID - 2)
		if not _is_land(gx, gz):
			continue
		var h := _terrain_height(float(gx), float(gz))
		if h < 45.0 or h > 340.0:
			continue
		var pos := _grid_vertex(gx, gz)
		var tree := Node3D.new()
		tree.position = pos
		var trunk := MeshInstance3D.new()
		trunk.mesh = trunk_mesh
		trunk.material_override = trunk_mat
		trunk.position.y = 4.5
		tree.add_child(trunk)
		var crown := MeshInstance3D.new()
		crown.mesh = crown_mesh
		crown.material_override = crown_mat
		crown.position.y = 12.0
		tree.add_child(crown)
		terrain_root.add_child(tree)

func _add_geographic_labels() -> void:
	_add_landmark("MEDITERRANEAN", Vector3(-1000, 5, -500), Color("#dce8e4"))
	_add_landmark("COASTAL PLAIN", _grid_vertex(13, 25) + Vector3(0, 18, 0), Color("#f1e6cf"))
	_add_landmark("CARMEL SLOPES", _grid_vertex(30, 22) + Vector3(0, 22, 0), Color("#f1e6cf"))
	_add_landmark("CARMEL RIDGE", _grid_vertex(38, 18) + Vector3(0, 30, 0), Color("#f1e6cf"))

func _add_landmark(label_text: String, pos: Vector3, color: Color) -> void:
	var marker := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 5.0
	sphere.height = 10.0
	marker.mesh = sphere
	marker.position = pos
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	marker.material_override = mat
	terrain_root.add_child(marker)

func _build_camera() -> void:
	camera = Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 2500.0
	camera.position = Vector3(1800, 2200, 2100)
	camera.look_at(camera_target, Vector3.UP)
	add_child(camera)
	camera.current = true

func _build_lighting() -> void:
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_energy = 1.15
	add_child(sun)
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_SKY
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#b9c6c2")
	environment.ambient_light_energy = 0.75
	env.environment = environment
	add_child(env)

func _build_ui() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	var top := PanelContainer.new()
	top.anchor_left = 0.02
	top.anchor_top = 0.02
	top.anchor_right = 0.98
	top.anchor_bottom = 0.02
	top.offset_bottom = 104
	hud.add_child(top)
	var top_box := VBoxContainer.new()
	top.add_child(top_box)
	var title := Label.new()
	title.text = "OLIVE & STONE  |  A STORY ROOTED IN PALESTINE"
	title.add_theme_font_size_override("font_size", 18)
	top_box.add_child(title)
	day_label = Label.new()
	top_box.add_child(day_label)
	resource_label = Label.new()
	resource_label.add_theme_font_size_override("font_size", 13)
	top_box.add_child(resource_label)
	population_label = Label.new()
	population_label.add_theme_font_size_override("font_size", 13)
	top_box.add_child(population_label)
	var bottom := PanelContainer.new()
	bottom.anchor_left = 0.02
	bottom.anchor_right = 0.98
	bottom.anchor_top = 1.0
	bottom.anchor_bottom = 1.0
	bottom.offset_top = -154
	bottom.offset_bottom = -10
	hud.add_child(bottom)
	var bottom_box := VBoxContainer.new()
	bottom.add_child(bottom_box)
	var hint := Label.new()
	hint.text = "BUILD — choose a structure, then tap a clear land area"
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bottom_box.add_child(hint)
	var build_row := HBoxContainer.new()
	build_row.alignment = BoxContainer.ALIGNMENT_CENTER
	bottom_box.add_child(build_row)
	for building_name in BUILDINGS.keys():
		var button := Button.new()
		button.text = building_name
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.custom_minimum_size = Vector2(0, 42)
		button.pressed.connect(_select_building.bind(building_name))
		build_row.add_child(button)
	var action_row := HBoxContainer.new()
	action_row.alignment = BoxContainer.ALIGNMENT_CENTER
	bottom_box.add_child(action_row)
	var save_button := Button.new()
	save_button.text = "Save settlement"
	save_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	save_button.pressed.connect(_save_game)
	action_row.add_child(save_button)
	var load_button := Button.new()
	load_button.text = "Load settlement"
	load_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	load_button.pressed.connect(_load_game)
	action_row.add_child(load_button)
	status_label = Label.new()
	status_label.anchor_left = 0.04
	status_label.anchor_right = 0.96
	status_label.anchor_top = 1.0
	status_label.anchor_bottom = 1.0
	status_label.offset_top = -190
	status_label.offset_bottom = -158
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hud.add_child(status_label)

func _create_survivors() -> void:
	var names := ["Mariam", "Yusuf", "Leila", "Omar", "Salma", "Khaled", "Nour", "Hassan", "Rana", "Tariq", "Amal", "Samir", "Huda", "Karim", "Dina"]
	var skills := ["Medicine", "Farming", "Construction", "Gathering", "Engineering"]
	for i in range(STARTING_POPULATION):
		survivors.append({"name": names[i], "skill": skills[i % skills.size()], "health": 100.0, "happiness": 70.0})

func _select_building(building_name: String) -> void:
	selected_building = building_name
	_set_status("Selected %s. Tap a clear land area to build." % building_name)

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
			camera.size = maxf(800.0, camera.size * 0.88)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
			camera.size = minf(4200.0, camera.size * 1.12)
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			mouse_dragging = event.pressed
			last_pointer = event.position
		elif event.button_index == MOUSE_BUTTON_LEFT and event.pressed and not selected_building.is_empty():
			_try_place_at(event.position)
	elif event is InputEventMouseMotion and mouse_dragging:
		_pan_camera(event.position - last_pointer)
		last_pointer = event.position
	elif event is InputEventScreenTouch:
		if event.pressed:
			pointer_start = event.position
			last_pointer = event.position
			touch_moved = false
			touch_dragging = true
		else:
			if touch_dragging and not touch_moved and not selected_building.is_empty():
				_try_place_at(event.position)
			touch_dragging = false
	elif event is InputEventScreenDrag and touch_dragging:
		if event.position.distance_to(pointer_start) > 10.0:
			touch_moved = true
			_pan_camera(event.relative)
	elif event is InputEventMagnifyGesture:
		camera.size = clampf(camera.size / event.factor, 800.0, 4200.0)

func _pan_camera(delta: Vector2) -> void:
	var scale := camera.size / 900.0
	var right := camera.global_transform.basis.x
	var forward := camera.global_transform.basis.z
	camera_target += (-right * delta.x + forward * delta.y) * scale * 1.2
	camera_target.x = clampf(camera_target.x, -1300.0, 1300.0)
	camera_target.z = clampf(camera_target.z, -1500.0, 1500.0)
	camera.position = camera_target + Vector3(1800, 2200, 2100)
	camera.look_at(camera_target, Vector3.UP)

func _try_place_at(screen_pos: Vector2) -> void:
	var origin := camera.project_ray_origin(screen_pos)
	var direction := camera.project_ray_normal(screen_pos)
	var query := PhysicsRayQueryParameters3D.create(origin, origin + direction * 10000.0)
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		_set_status("Tap on the land to place a building.")
		return
	var point: Vector3 = hit.position
	var gx := int(round(point.x / TILE_SIZE + GRID / 2.0 - 0.5))
	var gz := int(round(point.z / TILE_SIZE + GRID / 2.0 - 0.5))
	if not _is_land(gx, gz):
		_set_status("That location is outside the buildable land area.")
		return
	for existing in buildings:
		if int(existing["cell"][0]) == gx and int(existing["cell"][1]) == gz:
			_set_status("That location is already occupied.")
			return
	var data: Dictionary = BUILDINGS[selected_building]
	for resource in data["cost"]:
		if resources[resource] < data["cost"][resource]:
			_set_status("Not enough %s to build %s." % [resource, selected_building])
			return
	for resource in data["cost"]:
		resources[resource] -= data["cost"][resource]
	var pos := _grid_vertex(gx, gz)
	_create_building_visual(selected_building, pos, data["color"])
	buildings.append({"type": selected_building, "cell": [gx, gz], "position": [pos.x, pos.y, pos.z]})
	_set_status("%s constructed." % selected_building)
	selected_building = ""
	_refresh_ui()

func _create_building_visual(kind: String, pos: Vector3, color: Color) -> void:
	var root := Node3D.new()
	root.position = pos
	var body := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(30.0, 23.0, 27.0)
	body.mesh = box
	body.position.y = 11.5
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = 0.95
	body.material_override = mat
	root.add_child(body)
	var roof := MeshInstance3D.new()
	var roof_mesh := PrismMesh.new()
	roof_mesh.size = Vector3(34.0, 12.0, 31.0)
	roof.mesh = roof_mesh
	roof.position.y = 29.0
	var roof_mat := StandardMaterial3D.new()
	roof_mat.albedo_color = Color("#776b5c") if kind == "Shelter" else color.darkened(0.22)
	roof.material_override = roof_mat
	root.add_child(roof)
	building_root.add_child(root)

func _advance_day() -> void:
	day += 1
	resources["Food"] -= float(population) * 1.0
	resources["Water"] -= float(population) * 1.25
	for building in buildings:
		match building["type"]:
			"Farm": resources["Food"] += 24.0
			"Well": resources["Water"] += 28.0
			"Workshop": resources["Wood"] += 3.0
	if resources["Food"] < 0.0 or resources["Water"] < 0.0:
		health = maxf(0.0, health - 7.0)
		morale = maxf(0.0, morale - 8.0)
		_set_status("Shortages! Build farms and wells to protect the settlement.")
	else:
		morale = minf(100.0, morale + 1.0)
		_set_status("Day %d: production and consumption complete." % day)
	if day % 5 == 0 and _housing_capacity() > population and health > 40.0 and morale > 45.0:
		population += 1
		_set_status("A newcomer has joined your settlement.")
	_refresh_ui()

func _housing_capacity() -> int:
	var capacity := STARTING_POPULATION
	for building in buildings:
		if building["type"] == "Shelter": capacity += 5
	return capacity

func _refresh_ui() -> void:
	if not is_instance_valid(resource_label):
		return
	day_label.text = "DAY %d" % day
	resource_label.text = "Food %.0f   Water %.0f   Wood %.0f   Stone %.0f   Scrap %.0f" % [resources["Food"], resources["Water"], resources["Wood"], resources["Stone"], resources["Scrap"]]
	population_label.text = "Population %d / %d     Health %.0f%%     Morale %.0f%%" % [population, _housing_capacity(), health, morale]

func _set_status(message: String) -> void:
	if is_instance_valid(status_label):
		status_label.text = message

func _save_game() -> void:
	var data := {"region": "Haifa", "resources": resources, "population": population, "day": day, "morale": morale, "health": health, "buildings": buildings}
	var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if file == null:
		_set_status("Could not write save file.")
		return
	file.store_string(JSON.stringify(data))
	_set_status("Settlement saved on this device.")

func _load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		_set_status("No saved settlement found yet.")
		return
	var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
	var parsed = JSON.parse_string(file.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY or parsed.get("region", "") != "Haifa":
		_set_status("Save file is invalid or belongs to another region.")
		return
	resources = parsed.get("resources", resources)
	population = int(parsed.get("population", population))
	day = int(parsed.get("day", day))
	morale = float(parsed.get("morale", morale))
	health = float(parsed.get("health", health))
	buildings = parsed.get("buildings", [])
	for child in building_root.get_children():
		child.queue_free()
	for building in buildings:
		var p: Array = building["position"]
		_create_building_visual(building["type"], Vector3(float(p[0]), float(p[1]), float(p[2])), BUILDINGS[building["type"]]["color"])
	_refresh_ui()
	_set_status("Settlement loaded.")
