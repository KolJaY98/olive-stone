# Olive & Stone — A story rooted in Palestine

A lightweight Godot 4.3 isometric 3D colony-simulation prototype for Android. The first map is a simplified Haifa-region landscape: Mediterranean coast to the west, coastal plain, Carmel slopes and ridge inland.

## Current prototype
- Isometric orthographic 3D camera with touch drag panning and zoom gestures.
- Simplified Haifa-inspired coast-to-Carmel terrain blockout (not a surveyed DEM).
- Olive groves and stylized low-poly settlement buildings.
- 15 starting survivors; Food, Water, Wood, Stone and Scrap.
- Shelter, Well, Farm and Workshop construction.
- Daily consumption/production, shortages, health, morale and population growth.
- Local save/load.

## Build an Android debug APK from a phone (GitHub Actions)
The source ZIP includes a corrected Android export preset. The repository workflow extracts the ZIP, configures a temporary debug signing key, installs Android build dependencies, exports with Godot 4.3, and uploads the APK as a workflow artifact. No computer or local Android SDK is needed.

1. Create a new GitHub repository named `olive-and-stone`.
2. Upload the contents of this project folder to the repository root (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and enable workflows if GitHub asks.
4. Select **Build Android APK** and press **Run workflow**. A push to `main` or `master` also starts a build.
5. When the run finishes successfully, open the run, scroll to **Artifacts**, and download `olive-and-stone-android-debug-apk`.
6. Extract the artifact ZIP on your Android phone and tap `olive_stone_debug.apk` to install. If Android blocks installation, allow your browser or file manager to install unknown apps for this one installation.

The APK is a debug build for testing, not a Play Store release. It targets 64-bit ARM Android devices.

## Build details
- Godot 4.3 stable and its matching export templates.
- OpenJDK 17.
- Android SDK platform 34, build-tools 34.0.0 and NDK 23.2.8568313.
- Package ID: `org.oliveandstone.palestine`.

## Geography and limitations
The current landform is a deliberately simple Haifa-inspired blockout, not an exact digital elevation model. It captures the broad coastal-to-Carmel relationship for the first playable build, but exact coastline, elevation, wadis and road alignments still need real GIS data. The APK workflow builds the current prototype; it does not certify the game as bug-free or device-tested.

## Next milestones
1. Verify the first cloud APK build and test it on a real Android phone.
2. Replace the hand-shaped blockout with a simplified terrain mesh derived from real Haifa elevation/coastline data.
3. Improve touch UX, camera framing, survivor job assignment and production balance.
4. Add seasons, water catchments, roads and events.
5. Expand towards neighbouring settlements, trade and diplomacy.
