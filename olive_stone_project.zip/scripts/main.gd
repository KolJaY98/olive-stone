extends Node3D
# Olive & Stone - minimal playable base: isometric view, resources, build button.

var wood := 50
var stone := 20
var food := 30
var population := 3
var houses := 0
var _timer := 0.0

var _label: Label
var _button: Button
var _buildings: Node3D


func _ready() -> void:
	_setup_environment()
	_setup_camera()
	_setup_ground()
	_buildings = Node3D.new()
	add_child(_buildings)
	_setup_ui()
	_update_ui()


func _setup_environment() -> void:
	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-50, -30, 0)
	add_child(light)
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.82, 0.76, 0.62)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.7, 0.7, 0.7)
	var world_env := WorldEnvironment.new()
	world_env.environment = env
	add_child(world_env)


func _setup_camera() -> void:
	var cam := Camera3D.new()
	cam.projection = Camera3D.PROJECTION_ORTHOGONAL
	cam.size = 14.0
	cam.position = Vector3(12, 12, 12)
	add_child(cam)
	cam.look_at(Vector3.ZERO, Vector3.UP)


func _setup_ground() -> void:
	var mesh := MeshInstance3D.new()
	var plane := BoxMesh.new()
	plane.size = Vector3(16, 0.5, 16)
	mesh.mesh = plane
	mesh.position = Vector3(0, -0.25, 0)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.55, 0.6, 0.35)
	mesh.material_override = mat
	add_child(mesh)


func _setup_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	_label = Label.new()
	_label.position = Vector2(24, 16)
	_label.add_theme_font_size_override("font_size", 36)
	_label.add_theme_color_override("font_color", Color(0.1, 0.1, 0.1))
	layer.add_child(_label)
	_button = Button.new()
	_button.text = "Build house (20 wood, 5 stone)"
	_button.add_theme_font_size_override("font_size", 32)
	_button.position = Vector2(24, 620)
	_button.size = Vector2(620, 80)
	_button.pressed.connect(_on_build_pressed)
	layer.add_child(_button)


func _on_build_pressed() -> void:
	if wood < 20 or stone < 5:
		return
	wood -= 20
	stone -= 5
	var col := houses % 4
	var row := houses / 4
	var house := MeshInstance3D.new()
	var box := BoxMesh.new()
	box.size = Vector3(1.6, 1.2, 1.6)
	house.mesh = box
	house.position = Vector3(-5.0 + col * 3.0, 0.6, -5.0 + row * 3.0)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.85, 0.8, 0.7)
	house.material_override = mat
	_buildings.add_child(house)
	houses += 1
	population += 2
	_update_ui()


func _process(delta: float) -> void:
	_timer += delta
	if _timer >= 2.0:
		_timer = 0.0
		wood += 3
		stone += 1
		food += 2
		food -= int(population / 3)
		food = max(food, 0)
		_update_ui()


func _update_ui() -> void:
	_label.text = "Wood %d   Stone %d   Food %d   Population %d" % [wood, stone, food, population]
	_button.disabled = wood < 20 or stone < 5
