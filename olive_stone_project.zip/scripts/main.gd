extends Node3D

# Olive & Stone v0.3 - colony-simulation prototype rooted in Palestine.
# Geographic layout is a simplified Haifa-area blockout, not a surveyed DEM.
# Map orientation: Mediterranean west (left), Carmel ridge inland (east/right).
# Economy: nothing grows by itself. Villagers walk to resource points, gather,
# carry the load back to the camp (or a Storehouse) and only then it counts.

const VERSION := "0.3.0"
const GRID := 48
const TILE_SIZE := 75.0
const BASE_HOUSING := 15
const STARTING_POPULATION := 15
const SAVE_PATH := "user://olive_stone_save.json"
const AUTOSAVE_PATH := "user://olive_stone_autosave.json"
const SETTINGS_PATH := "user://settings.cfg"
const SAVE_VERSION := 3
const WORLD_SEED := 987654
const SEA_COLOR := Color("#477f91")
const DAY_LENGTH := 12.0
const WALK_SPEED := 70.0
const FOOD_PER_VILLAGER := 0.5
const WATER_PER_VILLAGER := 0.6
const AUTOSAVE_EVERY := 120.0
const CAM_OFFSET := Vector3(1800, 2200, 2100)
const CAMP_CELL := Vector2i(15, 24)
const RES_NAMES := ["Food", "Water", "Wood", "Stone", "Scrap"]
const RES_COLORS := {
	"Food": Color("#d9a441"), "Water": Color("#4aa3d9"), "Wood": Color("#9a6b3c"),
	"Stone": Color("#c8c0aa"), "Scrap": Color("#c77b4a")
}
const RES_SHORT := {"Food": "Fd", "Water": "Wt", "Wood": "Wd", "Stone": "St", "Scrap": "Sc"}
const START_RESOURCES := {"Food": 90.0, "Water": 110.0, "Wood": 100.0, "Stone": 85.0, "Scrap": 45.0}
const START_JOBS := {"Food": 2, "Water": 2, "Wood": 2, "Stone": 2, "Scrap": 1}
const TEXT_SIZES := [0.85, 1.0, 1.25]
const TEXT_SIZE_NAMES := ["Small", "Medium", "Large"]
const NAMES := [
	"Mariam", "Yusuf", "Leila", "Omar", "Salma", "Khaled", "Nour", "Hassan", "Rana", "Tariq",
	"Amal", "Samir", "Huda", "Karim", "Dina", "Fadi", "Layan", "Bassam", "Hanan", "Ziad",
	"Reem", "Jamal", "Sara", "Walid", "Ines", "Majd", "Lina", "Rami", "Farah", "Nabil"
]
const SKILLS := ["Medicine", "Farming", "Construction", "Gathering", "Engineering"]
const SKILL_COLORS := {
	"Medicine": Color("#e07070"), "Farming": Color("#7fb04f"), "Construction": Color("#e0a040"),
	"Gathering": Color("#8a6bb0"), "Engineering": Color("#4a90c0")
}

# Natural resource points scattered over the map (placed deterministically).
const SOURCE_DEFS := {
	"Food": {"count": 5, "min": 3.0, "max": 7.0, "yield": 10.0, "time": 3.0, "amount": 160.0, "regen": 0.10, "infinite": false, "label": "Wild figs and herbs"},
	"Water": {"count": 3, "min": 4.0, "max": 8.0, "yield": 12.0, "time": 2.0, "amount": 0.0, "regen": 0.0, "infinite": true, "label": "Spring"},
	"Wood": {"count": 6, "min": 3.5, "max": 9.0, "yield": 12.0, "time": 3.5, "amount": 220.0, "regen": 0.06, "infinite": false, "label": "Pine and carob trees"},
	"Stone": {"count": 5, "min": 4.0, "max": 9.5, "yield": 12.0, "time": 4.0, "amount": 260.0, "regen": 0.0, "infinite": false, "label": "Limestone outcrop"},
	"Scrap": {"count": 3, "min": 4.0, "max": 9.0, "yield": 8.0, "time": 4.0, "amount": 120.0, "regen": 0.0, "infinite": false, "label": "Old ruins"}
}

const BUILDINGS := {
	"Shelter": {
		"cost": {"Wood": 18.0, "Stone": 8.0}, "time": 10.0, "housing": 5, "gather": {}, "storage": false,
		"description": "Housing +5 villagers."
	},
	"Storehouse": {
		"cost": {"Wood": 25.0, "Stone": 10.0}, "time": 12.0, "housing": 0, "gather": {}, "storage": true,
		"description": "Drop-off point. Build it near resources to shorten trips."
	},
	"Well": {
		"cost": {"Stone": 22.0, "Wood": 8.0}, "time": 12.0, "housing": 0, "storage": false,
		"gather": {"res": "Water", "yield": 18.0, "time": 1.5, "slots": 3},
		"description": "Endless water point close to home (3 water carriers)."
	},
	"Farm": {
		"cost": {"Wood": 12.0, "Stone": 5.0}, "time": 12.0, "housing": 0, "storage": false,
		"gather": {"res": "Food", "yield": 20.0, "time": 2.5, "slots": 2},
		"description": "Endless food point, big harvests (2 farmers)."
	},
	"Olive Grove": {
		"cost": {"Wood": 14.0, "Stone": 4.0}, "time": 12.0, "housing": 0, "storage": false,
		"gather": {"res": "Food", "yield": 14.0, "time": 1.5, "slots": 3},
		"description": "Endless food point, quick picking (3 pickers)."
	},
	"Quarry": {
		"cost": {"Wood": 20.0, "Scrap": 6.0}, "time": 16.0, "housing": 0, "storage": false,
		"gather": {"res": "Stone", "yield": 16.0, "time": 3.0, "slots": 3},
		"description": "Endless stone point (3 quarrymen)."
	},
	"Workshop": {
		"cost": {"Wood": 18.0, "Stone": 12.0, "Scrap": 6.0}, "time": 18.0, "housing": 0, "storage": false,
		"gather": {"res": "Scrap", "yield": 10.0, "time": 3.0, "slots": 2},
		"description": "Endless scrap point: salvage and repair (2 workers)."
	}
}

const GOALS := [
	{"key": "workers", "text": "Tap Workers and decide who gathers what."},
	{"key": "shelter", "text": "Build a Shelter: housing for newcomers."},
	{"key": "storehouse", "text": "Build a Storehouse to shorten gathering trips."},
	{"key": "well", "text": "Build a Well for steady water."},
	{"key": "food", "text": "Build a Farm or Olive Grove for steady food."},
	{"key": "pop20", "text": "Grow the settlement to 20 villagers."},
	{"key": "day30", "text": "Survive until day 30."}
]


class Building:
	var type := ""
	var cell := Vector2i.ZERO
	var pos := Vector3.ZERO
	var progress := 0.0
	var done := false
	var node: Node3D
	var model: Node3D
	var scaffold: Node3D
	var label: Label3D


class Source:
	var res := ""
	var label := ""
	var pos := Vector3.ZERO
	var amount := 0.0
	var max_amount := 0.0
	var infinite := false
	var yield_amt := 10.0
	var gather_time := 3.0
	var slots := 3
	var regen := 0.0
	var building: Building = null
	var node: Node3D


class Villager:
	var vname := ""
	var skill := ""
	var node: Node3D
	var carry_node: MeshInstance3D
	var task := "idle"
	var job := ""
	var state := ""
	var target: Building = null
	var src: Source = null
	var releasing := false
	var carry_res := ""
	var carry_amt := 0.0
	var goal := Vector3.ZERO
	var wait := 0.0
	var timer := 0.0
	var phase := 0.0


var resources: Dictionary = START_RESOURCES.duplicate()
var jobs: Dictionary = START_JOBS.duplicate()
var income_today := {"Food": 0.0, "Water": 0.0, "Wood": 0.0, "Stone": 0.0, "Scrap": 0.0}
var last_income := {"Food": 0.0, "Water": 0.0, "Wood": 0.0, "Stone": 0.0, "Scrap": 0.0}
var day := 1
var day_timer := 0.0
var morale := 76.0
var health := 100.0
var peak_pop := STARTING_POPULATION
var game_speed := 1.0
var paused := false
var menu_open := false
var game_over := false
var goal_index := 0
var workers_opened := false
var text_size_index := 1
var selected_building := ""
var inspected: Building = null
var demolish_armed := false
var new_armed := false
var ghost_cell := Vector2i(-1, -1)
var ghost_valid := false
var buildings: Array[Building] = []
var sources: Array[Source] = []
var survivors: Array[Villager] = []
var heights := PackedFloat32Array()
var camp_pos := Vector3.ZERO
var rng := RandomNumberGenerator.new()
var mat_cache := {}
var stone_texture: ImageTexture
var no_source_day := {}

var camera: Camera3D
var camera_target := Vector3.ZERO
var terrain_root: Node3D
var building_root: Node3D
var source_root: Node3D
var villager_root: Node3D
var ghost: Node3D
var ghost_mat: StandardMaterial3D

var drag_active := false
var drag_moved := false
var press_pos := Vector2.ZERO
var right_drag := false
var touches := {}
var pinch_last := 0.0

var hud: CanvasLayer
var ui_root: Control
var day_label: Label
var day_bar: ProgressBar
var res_value_labels := {}
var res_name_labels := {}
var pop_label: Label
var morale_bar: ProgressBar
var health_bar: ProgressBar
var toast_panel: PanelContainer
var toast_label: Label
var toast_time := 0.0
var goal_label: Label
var pause_banner: PanelContainer
var pause_btn: Button
var speed_btn: Button
var workers_btn: Button
var workers_panel: PanelContainer
var job_count_labels := {}
var free_label: Label
var villager_list: VBoxContainer
var villager_labels: Array[Label] = []
var bottom_panel: PanelContainer
var info_label: Label
var cards_row: HBoxContainer
var card_buttons := {}
var confirm_row: HBoxContainer
var confirm_btn: Button
var inspect_row: HBoxContainer
var demolish_btn: Button
var menu_layer: Control
var text_size_btn: Button
var new_btn: Button
var over_layer: Control
var over_label: Label
var ui_timer := 0.0
var assign_timer := 0.0
var autosave_timer := 0.0


func _ready() -> void:
	rng.randomize()
	_load_settings()
	stone_texture = _make_stone_texture()
	_build_heights()
	camp_pos = _grid_vertex(CAMP_CELL.x, CAMP_CELL.y)
	_build_world()
	_generate_sources()
	_build_camp()
	_build_camera()
	_build_lighting()
	_build_ghost()
	_build_ui()
	_create_survivors()
	_assign_tasks()
	_refresh_ui()
	_toast("Welcome to Haifa. Your villagers gather everything by hand: assign them in Workers.", 7.0)


# ---------------------------------------------------------------- terrain

func _terrain_height(gx: float, gz: float) -> float:
	var east := gx / float(GRID - 1)
	var north_south := gz / float(GRID - 1)
	var escarpment_center := 0.58 + 0.045 * sin((north_south * 1.2 + 0.12) * TAU)
	var rise := 430.0 / (1.0 + exp(-19.0 * (east - escarpment_center)))
	var ridge_center := 0.77 + 0.025 * sin(north_south * TAU * 1.4)
	var ridge := 75.0 * exp(-pow((east - ridge_center) / 0.075, 2.0))
	var wadi_a := 32.0 * exp(-pow((east - (0.47 + 0.035 * sin(north_south * 8.0))) / 0.028, 2.0))
	var wadi_b := 24.0 * exp(-pow((east - (0.68 + 0.025 * cos(north_south * 7.0))) / 0.025, 2.0))
	var local_relief := 9.0 * sin(gx * 0.39) * cos(gz * 0.31) + 5.0 * sin(gz * 0.67)
	return maxf(3.0, rise + ridge + local_relief - wadi_a - wadi_b)


func _coastline_x(gz: float) -> float:
	return 5.2 + 1.4 * sin(gz * 0.13) + 0.65 * sin(gz * 0.31 + 1.0)


func _is_land(gx: int, gz: int) -> bool:
	return gx >= 0 and gx < GRID and gz >= 0 and gz < GRID and float(gx) >= _coastline_x(float(gz)) + 1.0


func _build_heights() -> void:
	heights.resize(GRID * GRID)
	for z in range(GRID):
		for x in range(GRID):
			heights[z * GRID + x] = _terrain_height(float(x), float(z))


func _height_at_world(x: float, z: float) -> float:
	var gx := clampf(x / TILE_SIZE + GRID / 2.0 - 0.5, 0.0, float(GRID) - 1.001)
	var gz := clampf(z / TILE_SIZE + GRID / 2.0 - 0.5, 0.0, float(GRID) - 1.001)
	var ix := int(gx)
	var iz := int(gz)
	var fx := gx - float(ix)
	var fz := gz - float(iz)
	var h00 := heights[iz * GRID + ix]
	var h10 := heights[iz * GRID + ix + 1]
	var h01 := heights[(iz + 1) * GRID + ix]
	var h11 := heights[(iz + 1) * GRID + ix + 1]
	return lerpf(lerpf(h00, h10, fx), lerpf(h01, h11, fx), fz)


func _grid_vertex(gx: int, gz: int) -> Vector3:
	var x := (float(gx) - GRID / 2.0 + 0.5) * TILE_SIZE
	var z := (float(gz) - GRID / 2.0 + 0.5) * TILE_SIZE
	return Vector3(x, _terrain_height(float(gx), float(gz)), z)


func _cell_from_point(p: Vector3) -> Vector2i:
	return Vector2i(int(round(p.x / TILE_SIZE + GRID / 2.0 - 0.5)), int(round(p.z / TILE_SIZE + GRID / 2.0 - 0.5)))


func _footing_range(x: float, z: float) -> Vector2:
	var lo := _height_at_world(x, z)
	var hi := lo
	for ox in [-26.0, 26.0]:
		for oz in [-26.0, 26.0]:
			var h := _height_at_world(x + ox, z + oz)
			lo = minf(lo, h)
			hi = maxf(hi, h)
	return Vector2(lo, hi)


func _build_world() -> void:
	terrain_root = Node3D.new()
	terrain_root.name = "HaifaTerrain"
	add_child(terrain_root)
	source_root = Node3D.new()
	source_root.name = "ResourcePoints"
	add_child(source_root)
	building_root = Node3D.new()
	building_root.name = "SettlementBuildings"
	add_child(building_root)
	villager_root = Node3D.new()
	villager_root.name = "Villagers"
	add_child(villager_root)
	_build_sea()
	_build_land_mesh()
	_add_olive_groves()
	_add_geographic_labels()


func _build_sea() -> void:
	var base := MeshInstance3D.new()
	var base_plane := PlaneMesh.new()
	base_plane.size = Vector2(14000.0, 14000.0)
	base.mesh = base_plane
	base.position = Vector3(0.0, -3.0, 0.0)
	base.material_override = _mat(Color("#a89a78"), 1.0)
	terrain_root.add_child(base)
	var sea := MeshInstance3D.new()
	var plane := PlaneMesh.new()
	plane.size = Vector2(4000.0, 9000.0)
	sea.mesh = plane
	sea.position = Vector3(-3000.0, -1.0, 0.0)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = SEA_COLOR
	mat.roughness = 0.32
	mat.metallic = 0.05
	sea.material_override = mat
	terrain_root.add_child(sea)


func _build_land_mesh() -> void:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	for x in range(GRID - 1):
		for z in range(GRID - 1):
			var center_x := x + 0.5
			if center_x < _coastline_x(float(z) + 0.5):
				continue
			var p00 := _grid_vertex(x, z)
			var p10 := _grid_vertex(x + 1, z)
			var p01 := _grid_vertex(x, z + 1)
			var p11 := _grid_vertex(x + 1, z + 1)
			_add_terrain_triangle(st, p00, p01, p10, x, z)
			_add_terrain_triangle(st, p10, p01, p11, x, z)
	st.generate_normals()
	var surface := MeshInstance3D.new()
	surface.name = "TerrainSurface"
	surface.mesh = st.commit()
	var mat := StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 1.0
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	surface.material_override = mat
	terrain_root.add_child(surface)


func _add_terrain_triangle(st: SurfaceTool, a: Vector3, b: Vector3, c: Vector3, gx: int, gz: int) -> void:
	st.set_color(_terrain_color((a.y + b.y + c.y) / 3.0, gx, gz))
	st.add_vertex(a)
	st.add_vertex(b)
	st.add_vertex(c)


func _terrain_color(elevation: float, gx: int, gz: int) -> Color:
	if elevation > 350.0:
		return Color("#b5ad99") if (gx + gz) % 4 else Color("#a49c89")
	if elevation > 190.0:
		return Color("#858b68") if (gx * 3 + gz) % 5 else Color("#a29b78")
	if elevation > 65.0:
		return Color("#899064") if (gx + gz) % 3 else Color("#a39a70")
	return Color("#b6a27b") if (gx + gz) % 4 else Color("#c0ad85")


func _add_olive_groves() -> void:
	var wr := RandomNumberGenerator.new()
	wr.seed = WORLD_SEED + 1
	var trunk_mesh := CylinderMesh.new()
	trunk_mesh.top_radius = 2.0
	trunk_mesh.bottom_radius = 3.2
	trunk_mesh.height = 20.0
	var crown_mesh := SphereMesh.new()
	crown_mesh.radius = 15.0
	crown_mesh.height = 24.0
	var spots: Array[Vector3] = []
	for i in range(260):
		var gx := wr.randi_range(8, GRID - 2)
		var gz := wr.randi_range(0, GRID - 2)
		if not _is_land(gx, gz):
			continue
		if Vector2(Vector2i(gx, gz) - CAMP_CELL).length() < 3.0:
			continue
		var base := _grid_vertex(gx, gz)
		if base.y > 330.0:
			continue
		var px := base.x + wr.randf_range(-28.0, 28.0)
		var pz := base.z + wr.randf_range(-28.0, 28.0)
		spots.append(Vector3(px, _height_at_world(px, pz), pz))
	var trunks := MultiMesh.new()
	trunks.transform_format = MultiMesh.TRANSFORM_3D
	trunks.mesh = trunk_mesh
	trunks.instance_count = spots.size()
	var crowns := MultiMesh.new()
	crowns.transform_format = MultiMesh.TRANSFORM_3D
	crowns.mesh = crown_mesh
	crowns.instance_count = spots.size()
	for i in range(spots.size()):
		var s := wr.randf_range(0.8, 1.25)
		var basis := Basis.from_scale(Vector3(s, s, s))
		trunks.set_instance_transform(i, Transform3D(basis, spots[i] + Vector3(0.0, 10.0 * s, 0.0)))
		crowns.set_instance_transform(i, Transform3D(basis, spots[i] + Vector3(0.0, 28.0 * s, 0.0)))
	var trunk_node := MultiMeshInstance3D.new()
	trunk_node.multimesh = trunks
	trunk_node.material_override = _mat(Color("#66513a"))
	terrain_root.add_child(trunk_node)
	var crown_node := MultiMeshInstance3D.new()
	crown_node.multimesh = crowns
	crown_node.material_override = _mat(Color("#6d7d4c"))
	terrain_root.add_child(crown_node)


func _add_geographic_labels() -> void:
	_add_world_label("MEDITERRANEAN SEA", Vector3(-1900, 30, -300), 2.4)
	_add_world_label("COASTAL PLAIN", _grid_vertex(11, 33) + Vector3(0, 50, 0), 1.6)
	_add_world_label("CARMEL SLOPES", _grid_vertex(30, 22) + Vector3(0, 60, 0), 1.6)
	_add_world_label("CARMEL RIDGE", _grid_vertex(38, 16) + Vector3(0, 70, 0), 1.6)


func _add_world_label(text: String, pos: Vector3, pixel_size: float) -> void:
	var label := Label3D.new()
	label.text = text
	label.font_size = 28
	label.pixel_size = pixel_size
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.no_depth_test = true
	label.outline_size = 8
	label.modulate = Color(1, 1, 1, 0.7)
	label.position = pos
	terrain_root.add_child(label)


func _build_camp() -> void:
	var camp := Node3D.new()
	camp.name = "Camp"
	camp.position = camp_pos
	terrain_root.add_child(camp)
	_cyl(camp, 9.0, 11.0, 6.0, Vector3(0, 3, 0), Color("#4a4038"))
	var flame := _cyl(camp, 0.0, 6.0, 18.0, Vector3(0, 14, 0), Color("#ff9a3c"))
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color("#ff9a3c")
	fm.emission_enabled = true
	fm.emission = Color("#ff7a1a")
	flame.material_override = fm
	for i in range(3):
		var a := TAU * float(i) / 3.0 + 0.5
		var tp := Vector3(cos(a) * 95.0, 0.0, sin(a) * 95.0)
		var tent := _prism(camp, Vector3(48, 34, 48), tp + Vector3(0, 17, 0), Color("#d8cba6"))
		tent.rotation.y = -a
	_add_world_label("CAMP", Vector3(0, 90, 0), 1.0)


# ---------------------------------------------------------------- resource points

func _generate_sources() -> void:
	var wr := RandomNumberGenerator.new()
	wr.seed = WORLD_SEED
	var taken: Array[Vector2i] = [CAMP_CELL]
	for key in SOURCE_DEFS:
		var res: String = key
		var d: Dictionary = SOURCE_DEFS[res]
		var placed := 0
		var tries := 0
		while placed < int(d["count"]) and tries < 4000:
			tries += 1
			var cell := Vector2i(wr.randi_range(6, GRID - 2), wr.randi_range(2, GRID - 3))
			var dist := Vector2(cell - CAMP_CELL).length()
			if dist < float(d["min"]) or dist > float(d["max"]):
				continue
			if res == "Water" and (cell.x < 19 or cell.x > 24):
				continue
			if not _is_land(cell.x, cell.y):
				continue
			var too_close := false
			for t in taken:
				if Vector2(cell - t).length() < 2.0:
					too_close = true
					break
			if too_close:
				continue
			var v := _grid_vertex(cell.x, cell.y)
			var fr := _footing_range(v.x, v.z)
			if fr.y - fr.x > 40.0 or v.y > 330.0:
				continue
			taken.append(cell)
			var s := Source.new()
			s.res = res
			s.label = str(d["label"])
			s.pos = Vector3(v.x, fr.y, v.z)
			s.infinite = bool(d["infinite"])
			s.amount = float(d["amount"])
			s.max_amount = float(d["amount"])
			s.yield_amt = float(d["yield"])
			s.gather_time = float(d["time"])
			s.slots = 3
			s.regen = float(d["regen"])
			s.node = _make_source_visual(res)
			s.node.position = s.pos
			source_root.add_child(s.node)
			sources.append(s)
			placed += 1


func _make_source_visual(res: String) -> Node3D:
	var n := Node3D.new()
	match res:
		"Wood":
			for p in [Vector3(-14, 0, 6), Vector3(10, 0, -8), Vector3(16, 0, 14)]:
				_cyl(n, 2.4, 3.0, 20.0, p + Vector3(0, 10, 0), Color("#6b4f33"))
				_cyl(n, 0.0, 15.0, 34.0, p + Vector3(0, 36, 0), Color("#4f6b3a"))
		"Stone":
			var rocks := [
				[Vector3(-10, 9, 0), Vector3(26, 18, 22), 20.0],
				[Vector3(14, 7, 8), Vector3(20, 14, 18), -25.0],
				[Vector3(6, 6, -14), Vector3(16, 12, 14), 40.0]
			]
			for rk in rocks:
				var rock := _box(n, rk[1], rk[0], Color("#ffffff"), true)
				rock.rotation_degrees.y = rk[2]
		"Water":
			_cyl(n, 20.0, 21.0, 5.0, Vector3(0, 2.5, 0), Color("#ffffff"), true)
			_cyl(n, 15.0, 15.0, 1.5, Vector3(0, 4.9, 0), Color("#4aa3d9"))
			for p in [Vector3(-18, 0, 12), Vector3(-12, 0, 18), Vector3(20, 0, -10)]:
				_box(n, Vector3(2, 18, 2), p + Vector3(0, 9, 0), Color("#6f8f3d"))
		"Food":
			for p in [Vector3(-14, 0, 4), Vector3(8, 0, -10), Vector3(14, 0, 12)]:
				_sphere(n, 9.0, p + Vector3(0, 7, 0), Color("#8a9a45"))
				_sphere(n, 2.4, p + Vector3(5, 12, 4), Color("#d9a441"))
				_sphere(n, 2.4, p + Vector3(-4, 10, 6), Color("#d9a441"))
		"Scrap":
			_box(n, Vector3(34, 16, 8), Vector3(-6, 8, -8), Color("#ffffff"), true)
			_box(n, Vector3(10, 26, 8), Vector3(14, 13, -8), Color("#ffffff"), true)
			_box(n, Vector3(8, 5, 8), Vector3(-14, 2.5, 8), Color("#ffffff"), true)
			var sheet := _box(n, Vector3(20, 3, 14), Vector3(2, 5, 10), Color("#8a5a3a"))
			sheet.rotation_degrees = Vector3(8, 25, 4)
	return n


func _update_source_visual(s: Source) -> void:
	if s.node == null or s.infinite:
		return
	var ratio := clampf(s.amount / maxf(1.0, s.max_amount), 0.0, 1.0)
	s.node.scale = Vector3(1.0, lerpf(0.3, 1.0, ratio), 1.0)


func _add_building_source(b: Building) -> void:
	var def: Dictionary = BUILDINGS[b.type]
	var g: Dictionary = def["gather"]
	if g.is_empty():
		return
	var s := Source.new()
	s.res = str(g["res"])
	s.label = b.type
	s.pos = b.pos + Vector3(0, 0, 36)
	s.pos.y = _height_at_world(s.pos.x, s.pos.z)
	s.infinite = true
	s.yield_amt = float(g["yield"])
	s.gather_time = float(g["time"])
	s.slots = int(g["slots"])
	s.building = b
	sources.append(s)


# ---------------------------------------------------------------- materials / mesh helpers

func _make_stone_texture() -> ImageTexture:
	var w := 256
	var img := Image.create(w, w, false, Image.FORMAT_RGB8)
	var sr := RandomNumberGenerator.new()
	sr.seed = 77
	var base := Color("#e8d9b4")
	var mortar := Color("#b9a47c")
	var rows := 8
	var row_h := w / rows
	img.fill(mortar)
	for r in range(rows):
		var y0 := r * row_h
		var x := -sr.randi_range(0, 60)
		while x < w:
			var bw := sr.randi_range(56, 104)
			var tone := sr.randf_range(0.93, 1.04)
			var c := Color(minf(1.0, base.r * tone), minf(1.0, base.g * tone), minf(1.0, base.b * tone * sr.randf_range(0.96, 1.03)))
			for yy in range(y0 + 2, y0 + row_h - 1):
				for xx in range(maxi(x + 2, 0), mini(x + bw - 1, w)):
					img.set_pixel(xx, yy, c)
			x += bw
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


func _mat(color: Color, rough: float = 0.95) -> StandardMaterial3D:
	var key := "%s_%s" % [color.to_html(), rough]
	if mat_cache.has(key):
		return mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = rough
	mat_cache[key] = m
	return m


# Jerusalem stone: pale honey limestone laid in courses of ashlar blocks.
func _stone_mat(tint: Color = Color.WHITE) -> StandardMaterial3D:
	var key := "stone_" + tint.to_html()
	if mat_cache.has(key):
		return mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_texture = stone_texture
	m.albedo_color = tint
	m.uv1_triplanar = true
	m.uv1_scale = Vector3(0.022, 0.022, 0.022)
	m.roughness = 0.95
	mat_cache[key] = m
	return m


func _pick_mat(color: Color, stone: bool) -> StandardMaterial3D:
	return _stone_mat(color) if stone else _mat(color)


func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color, stone: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = _pick_mat(color, stone)
	parent.add_child(mi)
	return mi


func _cyl(parent: Node3D, top_r: float, bottom_r: float, h: float, pos: Vector3, color: Color, stone: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = top_r
	mesh.bottom_radius = bottom_r
	mesh.height = h
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = _pick_mat(color, stone)
	parent.add_child(mi)
	return mi


func _sphere(parent: Node3D, r: float, pos: Vector3, color: Color, stone: bool = false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = r
	mesh.height = r * 2.0
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = _pick_mat(color, stone)
	parent.add_child(mi)
	return mi


func _dome(parent: Node3D, r: float, pos: Vector3, color: Color = Color("#fff6e0")) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = r
	mesh.height = r
	mesh.is_hemisphere = true
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = _stone_mat(color)
	parent.add_child(mi)
	return mi


func _prism(parent: Node3D, size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := PrismMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = _mat(color)
	parent.add_child(mi)
	return mi


func _parapet(parent: Node3D, w: float, d: float, y: float, h: float = 4.0) -> void:
	var t := 3.0
	var c := Color("#f4ead0")
	_box(parent, Vector3(w, h, t), Vector3(0, y + h * 0.5, d * 0.5 - t * 0.5), c, true)
	_box(parent, Vector3(w, h, t), Vector3(0, y + h * 0.5, -d * 0.5 + t * 0.5), c, true)
	_box(parent, Vector3(t, h, d - 2.0 * t), Vector3(w * 0.5 - t * 0.5, y + h * 0.5, 0), c, true)
	_box(parent, Vector3(t, h, d - 2.0 * t), Vector3(-w * 0.5 + t * 0.5, y + h * 0.5, 0), c, true)


# Round-headed arch (door or window) on a front face at plane z.
func _arch(parent: Node3D, x: float, base_y: float, w: float, h: float, z: float, fill: Color) -> void:
	var r := w * 0.5
	var frame_col := Color("#f6edd2")
	var ring := _cyl(parent, r + 3.0, r + 3.0, 1.5, Vector3(x, base_y + h - r, z - 0.2), frame_col, true)
	ring.rotation_degrees.x = 90.0
	_box(parent, Vector3(w + 6.0, h - r, 1.5), Vector3(x, base_y + (h - r) * 0.5, z - 0.2), frame_col, true)
	var disc := _cyl(parent, r, r, 2.0, Vector3(x, base_y + h - r, z), fill)
	disc.rotation_degrees.x = 90.0
	_box(parent, Vector3(w, h - r, 2.0), Vector3(x, base_y + (h - r) * 0.5, z), fill)


# ---------------------------------------------------------------- building models (Jerusalem stone)

func _make_building_model(type: String) -> Node3D:
	var m := Node3D.new()
	var door := Color("#5a4632")
	var window := Color("#34444f")
	var cream := Color("#fff6e0")
	match type:
		"Shelter":
			_box(m, Vector3(46, 30, 42), Vector3(0, 15, 0), Color.WHITE, true)
			_box(m, Vector3(50, 3, 46), Vector3(0, 31.5, 0), cream, true)
			_parapet(m, 50.0, 46.0, 33.0)
			_dome(m, 13.0, Vector3(-9, 33, -6))
			_arch(m, 0, 0, 14, 22, 21.5, door)
			_arch(m, -15, 11, 8, 12, 21.5, window)
			_arch(m, 15, 11, 8, 12, 21.5, window)
		"Storehouse":
			_box(m, Vector3(52, 26, 44), Vector3(0, 13, 0), Color("#f4ead2"), true)
			_box(m, Vector3(56, 3, 48), Vector3(0, 27.5, 0), cream, true)
			_parapet(m, 56.0, 48.0, 29.0)
			_arch(m, -12, 0, 14, 20, 22.5, door)
			_arch(m, 12, 0, 14, 20, 22.5, door)
			for p in [Vector3(-22, 5, 30), Vector3(-14, 5, 32), Vector3(-18, 13, 31)]:
				_sphere(m, 5.5, p, Color("#d8c29a"))
			_box(m, Vector3(10, 8, 10), Vector3(22, 4, 30), Color("#8a6a40"))
			_box(m, Vector3(10, 8, 10), Vector3(22, 12, 30), Color("#9a7a50"))
		"Well":
			_cyl(m, 17.0, 18.0, 14.0, Vector3(0, 7, 0), Color.WHITE, true)
			_cyl(m, 13.0, 13.0, 1.5, Vector3(0, 14.5, 0), Color("#4aa3d9"))
			_box(m, Vector3(6, 36, 6), Vector3(-15, 18, 0), Color.WHITE, true)
			_box(m, Vector3(6, 36, 6), Vector3(15, 18, 0), Color.WHITE, true)
			_box(m, Vector3(40, 6, 9), Vector3(0, 39, 0), cream, true)
			_dome(m, 12.0, Vector3(0, 42, 0))
			_cyl(m, 3.0, 3.0, 6.0, Vector3(0, 30, 0), Color("#8a6a40"))
		"Farm":
			for i in range(3):
				var h := 6.0 + 6.0 * float(i)
				var z := 18.0 - 18.0 * float(i)
				_box(m, Vector3(58, h, 4), Vector3(0, h * 0.5, z + 8.0), Color.WHITE, true)
				_box(m, Vector3(58, 2, 15), Vector3(0, h + 1.0, z), Color("#6b4f33"))
				for k in range(3):
					_box(m, Vector3(50, 4, 3), Vector3(0, h + 4.0, z - 4.0 + 4.0 * float(k)), Color("#7fb04f"))
		"Olive Grove":
			_box(m, Vector3(60, 2, 54), Vector3(0, 1, 0), Color("#b9a878"))
			_box(m, Vector3(60, 5, 3), Vector3(0, 2.5, 27), Color.WHITE, true)
			_box(m, Vector3(60, 5, 3), Vector3(0, 2.5, -27), Color.WHITE, true)
			_box(m, Vector3(3, 5, 54), Vector3(30, 2.5, 0), Color.WHITE, true)
			_box(m, Vector3(3, 5, 54), Vector3(-30, 2.5, 0), Color.WHITE, true)
			for p in [Vector3(-18, 0, -14), Vector3(18, 0, -14), Vector3(0, 0, 0), Vector3(-18, 0, 14), Vector3(18, 0, 14)]:
				_cyl(m, 2.2, 3.4, 14.0, p + Vector3(0, 7, 0), Color("#7a6648"))
				_sphere(m, 9.5, p + Vector3(-3, 20, 0), Color("#7d8f5a"))
				_sphere(m, 8.0, p + Vector3(4, 22, 2), Color("#6d7d4c"))
		"Quarry":
			_box(m, Vector3(56, 8, 22), Vector3(0, 4, -15), Color.WHITE, true)
			_box(m, Vector3(42, 7, 18), Vector3(0, 11.5, -17), cream, true)
			_box(m, Vector3(28, 6, 14), Vector3(0, 18, -19), Color.WHITE, true)
			var b1 := _box(m, Vector3(14, 10, 12), Vector3(-18, 5, 12), cream, true)
			b1.rotation_degrees.y = 15.0
			var b2 := _box(m, Vector3(12, 8, 10), Vector3(14, 4, 16), Color.WHITE, true)
			b2.rotation_degrees.y = -20.0
			_box(m, Vector3(10, 6, 10), Vector3(0, 3, 22), cream, true)
			_cyl(m, 1.8, 1.8, 36.0, Vector3(24, 18, 4), Color("#8a6a40"))
			_box(m, Vector3(30, 2.5, 2.5), Vector3(10, 36, 4), Color("#8a6a40"))
		"Workshop":
			_box(m, Vector3(50, 26, 40), Vector3(0, 13, 0), Color.WHITE, true)
			var vault := _cyl(m, 21.0, 21.0, 50.0, Vector3(0, 26, 0), cream, true)
			vault.rotation_degrees.z = 90.0
			_box(m, Vector3(8, 22, 8), Vector3(16, 40, -10), Color("#f4ead2"), true)
			_arch(m, 0, 0, 20, 20, 20.5, door)
			_arch(m, -18, 10, 8, 10, 20.5, window)
			_arch(m, 18, 10, 8, 10, 20.5, window)
	return m


func _make_scaffold() -> Node3D:
	var s := Node3D.new()
	var wood := Color("#8a6a40")
	for sx in [-29.0, 29.0]:
		for sz in [-26.0, 26.0]:
			_cyl(s, 1.8, 1.8, 48.0, Vector3(sx, 26, sz), wood)
	_box(s, Vector3(62, 2.5, 2.5), Vector3(0, 44, -26), wood)
	_box(s, Vector3(62, 2.5, 2.5), Vector3(0, 44, 26), wood)
	return s


# ---------------------------------------------------------------- camera / light / ghost

func _build_camera() -> void:
	camera = Camera3D.new()
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 1000.0
	camera.near = 10.0
	camera.far = 12000.0
	add_child(camera)
	camera_target = Vector3(camp_pos.x, 0.0, camp_pos.z)
	_update_camera()
	camera.current = true


func _update_camera() -> void:
	camera.position = camera_target + CAM_OFFSET
	camera.look_at(camera_target, Vector3.UP)


func _build_lighting() -> void:
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -35, 0)
	sun.light_energy = 1.15
	add_child(sun)
	var env := WorldEnvironment.new()
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("#9cc3d5")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#b9c6c2")
	environment.ambient_light_energy = 0.75
	env.environment = environment
	add_child(env)


func _build_ghost() -> void:
	ghost = Node3D.new()
	ghost.visible = false
	add_child(ghost)
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(60, 40, 56)
	mi.mesh = mesh
	mi.position = Vector3(0, 20, 0)
	ghost_mat = StandardMaterial3D.new()
	ghost_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ghost_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	ghost_mat.albedo_color = Color(0.3, 0.9, 0.3, 0.55)
	mi.material_override = ghost_mat
	ghost.add_child(mi)


# ---------------------------------------------------------------- settings

func _load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		text_size_index = clampi(int(cf.get_value("ui", "text_size", 1)), 0, TEXT_SIZES.size() - 1)
	_apply_text_size()


func _apply_text_size() -> void:
	get_tree().root.content_scale_factor = float(TEXT_SIZES[text_size_index])


func _cycle_text_size() -> void:
	text_size_index = (text_size_index + 1) % TEXT_SIZES.size()
	_apply_text_size()
	var cf := ConfigFile.new()
	cf.set_value("ui", "text_size", text_size_index)
	cf.save(SETTINGS_PATH)
	if is_instance_valid(text_size_btn):
		text_size_btn.text = "Text size: %s" % TEXT_SIZE_NAMES[text_size_index]


# ---------------------------------------------------------------- UI

func _flat(color: Color, radius: int = 10, margin: int = 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = color
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(margin)
	return s


func _make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 22
	t.set_stylebox("normal", "Button", _flat(Color("#3f4d2e"), 12, 10))
	t.set_stylebox("hover", "Button", _flat(Color("#51643b"), 12, 10))
	t.set_stylebox("pressed", "Button", _flat(Color("#6b8450"), 12, 10))
	t.set_stylebox("disabled", "Button", _flat(Color("#2c3324"), 12, 10))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	t.set_color("font_color", "Button", Color("#f4efdc"))
	t.set_color("font_hover_color", "Button", Color.WHITE)
	t.set_color("font_pressed_color", "Button", Color.WHITE)
	t.set_color("font_disabled_color", "Button", Color("#8a8f7c"))
	t.set_stylebox("panel", "PanelContainer", _flat(Color(0.09, 0.11, 0.08, 0.88), 16, 12))
	t.set_color("font_color", "Label", Color("#f4efdc"))
	t.set_stylebox("background", "ProgressBar", _flat(Color(1, 1, 1, 0.14), 5, 0))
	t.set_stylebox("fill", "ProgressBar", _flat(Color("#8fae4a"), 5, 0))
	return t


func _make_button(text: String, callback: Callable, min_size: Vector2 = Vector2(0, 64), font_size: int = 22) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", font_size)
	b.pressed.connect(callback)
	return b


func _tint_button(b: Button, color: Color) -> void:
	b.add_theme_stylebox_override("normal", _flat(color, 12, 10))
	b.add_theme_stylebox_override("hover", _flat(color.lightened(0.12), 12, 10))
	b.add_theme_stylebox_override("pressed", _flat(color.lightened(0.25), 12, 10))


func _make_label(text: String, size: int, color: Color = Color("#f4efdc")) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l


func _build_ui() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	ui_root = Control.new()
	ui_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.theme = _make_theme()
	hud.add_child(ui_root)
	_build_top_bar()
	_build_side_buttons()
	_build_goal_panel()
	_build_workers_panel()
	_build_pause_banner()
	_build_toast()
	_build_bottom_bar()
	_build_menu()
	_build_game_over()


func _build_top_bar() -> void:
	var top := PanelContainer.new()
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_left = 10
	top.offset_right = -10
	top.offset_top = 8
	ui_root.add_child(top)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 18)
	top.add_child(row)
	var left := VBoxContainer.new()
	left.add_theme_constant_override("separation", 1)
	row.add_child(left)
	day_label = _make_label("Day 1", 22, Color("#e7d9a8"))
	left.add_child(day_label)
	day_bar = ProgressBar.new()
	day_bar.custom_minimum_size = Vector2(110, 8)
	day_bar.show_percentage = false
	left.add_child(day_bar)
	left.add_child(_make_label("v%s" % VERSION, 12, Color("#8f8a74")))
	for r in RES_NAMES:
		row.add_child(_make_chip(r))
	var pop_box := VBoxContainer.new()
	pop_box.add_theme_constant_override("separation", 0)
	row.add_child(pop_box)
	pop_box.add_child(_make_label("Villagers", 14, Color("#bfb99f")))
	pop_label = _make_label("0 / 0", 24)
	pop_box.add_child(pop_label)
	var meters := VBoxContainer.new()
	meters.custom_minimum_size = Vector2(110, 0)
	row.add_child(meters)
	meters.add_child(_make_label("Morale", 14, Color("#bfb99f")))
	morale_bar = _make_meter(Color("#5aa0d0"))
	meters.add_child(morale_bar)
	meters.add_child(_make_label("Health", 14, Color("#bfb99f")))
	health_bar = _make_meter(Color("#c0644a"))
	meters.add_child(health_bar)


func _make_chip(res: String) -> Control:
	var box := HBoxContainer.new()
	box.add_theme_constant_override("separation", 6)
	var sw := ColorRect.new()
	sw.color = RES_COLORS[res]
	sw.custom_minimum_size = Vector2(8, 40)
	box.add_child(sw)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 0)
	box.add_child(col)
	var name_l := _make_label(res, 14, Color("#bfb99f"))
	col.add_child(name_l)
	var val_l := _make_label("0", 24)
	col.add_child(val_l)
	res_name_labels[res] = name_l
	res_value_labels[res] = val_l
	return box


func _make_meter(color: Color) -> ProgressBar:
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(100, 10)
	bar.show_percentage = false
	bar.max_value = 100.0
	bar.add_theme_stylebox_override("fill", _flat(color, 5, 0))
	return bar


func _build_side_buttons() -> void:
	var col := VBoxContainer.new()
	col.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	col.grow_horizontal = Control.GROW_DIRECTION_BEGIN
	col.offset_right = -10
	col.offset_top = 104
	col.add_theme_constant_override("separation", 8)
	ui_root.add_child(col)
	pause_btn = _make_button("Pause", _toggle_pause, Vector2(132, 56), 20)
	col.add_child(pause_btn)
	workers_btn = _make_button("Workers", _toggle_workers, Vector2(132, 56), 20)
	col.add_child(workers_btn)
	speed_btn = _make_button("Speed x1", _cycle_speed, Vector2(132, 56), 20)
	col.add_child(speed_btn)
	col.add_child(_make_button("Menu", _open_menu, Vector2(132, 56), 20))


func _build_goal_panel() -> void:
	var p := PanelContainer.new()
	p.set_anchors_preset(Control.PRESET_TOP_LEFT)
	p.offset_left = 10
	p.offset_top = 104
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui_root.add_child(p)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 2)
	p.add_child(box)
	box.add_child(_make_label("GOAL", 13, Color("#e7d9a8")))
	goal_label = _make_label("", 17)
	goal_label.custom_minimum_size = Vector2(260, 0)
	goal_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	goal_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(goal_label)


func _build_workers_panel() -> void:
	workers_panel = PanelContainer.new()
	workers_panel.set_anchors_preset(Control.PRESET_RIGHT_WIDE)
	workers_panel.offset_left = -580
	workers_panel.offset_right = -160
	workers_panel.offset_top = 104
	workers_panel.offset_bottom = -210
	workers_panel.visible = false
	ui_root.add_child(workers_panel)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	workers_panel.add_child(scroll)
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 6)
	scroll.add_child(box)
	box.add_child(_make_label("Workers", 26, Color("#e7d9a8")))
	var hint := _make_label("Choose how many villagers gather each resource.", 15, Color("#bfb99f"))
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hint.custom_minimum_size = Vector2(300, 0)
	box.add_child(hint)
	for r in RES_NAMES:
		box.add_child(_make_job_row(r))
	free_label = _make_label("Free: 0", 20, Color("#cfd8a8"))
	box.add_child(free_label)
	box.add_child(_make_label("Villagers", 22, Color("#e7d9a8")))
	villager_list = VBoxContainer.new()
	villager_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	villager_list.add_theme_constant_override("separation", 4)
	box.add_child(villager_list)


func _make_job_row(res: String) -> Control:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var sw := ColorRect.new()
	sw.color = RES_COLORS[res]
	sw.custom_minimum_size = Vector2(8, 46)
	row.add_child(sw)
	var name_l := _make_label(res, 22)
	name_l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(name_l)
	row.add_child(_make_button("-", _change_job.bind(res, -1), Vector2(56, 52), 26))
	var count_l := _make_label("0", 24)
	count_l.custom_minimum_size = Vector2(34, 0)
	count_l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	row.add_child(count_l)
	row.add_child(_make_button("+", _change_job.bind(res, 1), Vector2(56, 52), 26))
	job_count_labels[res] = count_l
	return row


func _build_pause_banner() -> void:
	pause_banner = PanelContainer.new()
	pause_banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
	pause_banner.grow_horizontal = Control.GROW_DIRECTION_BOTH
	pause_banner.offset_top = 178
	pause_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pause_banner.visible = false
	ui_root.add_child(pause_banner)
	var l := _make_label("PAUSED - you can still look around and plan", 22, Color("#ffe9a0"))
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pause_banner.add_child(l)


func _build_toast() -> void:
	toast_panel = PanelContainer.new()
	toast_panel.set_anchors_preset(Control.PRESET_CENTER_TOP)
	toast_panel.grow_horizontal = Control.GROW_DIRECTION_BOTH
	toast_panel.offset_top = 104
	toast_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_panel.visible = false
	ui_root.add_child(toast_panel)
	toast_label = _make_label("", 21)
	toast_label.custom_minimum_size = Vector2(460, 0)
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_panel.add_child(toast_label)


func _build_bottom_bar() -> void:
	bottom_panel = PanelContainer.new()
	bottom_panel.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	bottom_panel.grow_vertical = Control.GROW_DIRECTION_BEGIN
	bottom_panel.offset_left = 10
	bottom_panel.offset_right = -10
	bottom_panel.offset_bottom = -8
	ui_root.add_child(bottom_panel)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	bottom_panel.add_child(box)
	info_label = _make_label("Choose a building to construct", 18, Color("#d9d2b4"))
	info_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(info_label)
	cards_row = HBoxContainer.new()
	cards_row.add_theme_constant_override("separation", 6)
	box.add_child(cards_row)
	for bname in BUILDINGS.keys():
		var def: Dictionary = BUILDINGS[bname]
		var btn := _make_button("%s\n%s" % [bname, _cost_short(def["cost"])], _select_building.bind(bname), Vector2(120, 84), 17)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		cards_row.add_child(btn)
		card_buttons[bname] = btn
	confirm_row = HBoxContainer.new()
	confirm_row.add_theme_constant_override("separation", 12)
	confirm_row.visible = false
	box.add_child(confirm_row)
	confirm_btn = _make_button("Build here", _confirm_build, Vector2(0, 76), 26)
	confirm_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tint_button(confirm_btn, Color("#4f7f3a"))
	confirm_row.add_child(confirm_btn)
	var cancel_btn := _make_button("Cancel", _cancel_placement, Vector2(0, 76), 26)
	cancel_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tint_button(cancel_btn, Color("#8a3f33"))
	confirm_row.add_child(cancel_btn)
	inspect_row = HBoxContainer.new()
	inspect_row.add_theme_constant_override("separation", 12)
	inspect_row.visible = false
	box.add_child(inspect_row)
	demolish_btn = _make_button("Demolish (refund 50%)", _demolish_pressed, Vector2(0, 70), 22)
	demolish_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_tint_button(demolish_btn, Color("#8a3f33"))
	inspect_row.add_child(demolish_btn)
	var close_btn := _make_button("Close", _close_inspect, Vector2(0, 70), 22)
	close_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	inspect_row.add_child(close_btn)


func _cost_short(cost: Dictionary) -> String:
	var parts: Array[String] = []
	for r in cost:
		parts.append("%s %d" % [RES_SHORT[r], int(cost[r])])
	return " ".join(parts)


func _cost_long(cost: Dictionary) -> String:
	var parts: Array[String] = []
	for r in cost:
		parts.append("%s %d" % [r, int(cost[r])])
	return ", ".join(parts)


func _build_menu() -> void:
	menu_layer = Control.new()
	menu_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	menu_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	menu_layer.visible = false
	ui_root.add_child(menu_layer)
	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.6)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	menu_layer.add_child(center)
	var panel := PanelContainer.new()
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(460, 0)
	vb.add_theme_constant_override("separation", 8)
	panel.add_child(vb)
	var title := _make_label("OLIVE & STONE", 30, Color("#e7d9a8"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)
	var sub := _make_label("A story rooted in Palestine   -   v%s" % VERSION, 16, Color("#bfb99f"))
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(sub)
	vb.add_child(_make_button("Resume", _close_menu, Vector2(0, 54), 22))
	vb.add_child(_make_button("Save settlement", _save_game, Vector2(0, 54), 22))
	vb.add_child(_make_button("Load settlement", _load_game.bind(SAVE_PATH), Vector2(0, 54), 22))
	vb.add_child(_make_button("Load autosave", _load_game.bind(AUTOSAVE_PATH), Vector2(0, 54), 22))
	text_size_btn = _make_button("Text size: %s" % TEXT_SIZE_NAMES[text_size_index], _cycle_text_size, Vector2(0, 54), 22)
	vb.add_child(text_size_btn)
	new_btn = _make_button("New settlement", _new_pressed, Vector2(0, 54), 22)
	_tint_button(new_btn, Color("#6b4a2e"))
	vb.add_child(new_btn)


func _build_game_over() -> void:
	over_layer = Control.new()
	over_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	over_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	over_layer.visible = false
	ui_root.add_child(over_layer)
	var dim := ColorRect.new()
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.color = Color(0, 0, 0, 0.72)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	over_layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	over_layer.add_child(center)
	var panel := PanelContainer.new()
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.custom_minimum_size = Vector2(520, 0)
	vb.add_theme_constant_override("separation", 12)
	panel.add_child(vb)
	var title := _make_label("The settlement has fallen", 30, Color("#e8806e"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(title)
	over_label = _make_label("", 20)
	over_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	over_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(over_label)
	vb.add_child(_make_button("Load autosave", _load_game.bind(AUTOSAVE_PATH), Vector2(0, 58), 22))
	var again := _make_button("New settlement", _restart_game, Vector2(0, 62), 24)
	_tint_button(again, Color("#4f7f3a"))
	vb.add_child(again)


# ---------------------------------------------------------------- UI actions

func _open_menu() -> void:
	menu_open = true
	menu_layer.visible = true
	new_armed = false
	new_btn.text = "New settlement"


func _close_menu() -> void:
	menu_open = false
	menu_layer.visible = false


func _toggle_pause() -> void:
	paused = not paused
	pause_banner.visible = paused
	pause_btn.text = "Resume" if paused else "Pause"


func _toggle_workers() -> void:
	workers_panel.visible = not workers_panel.visible
	if workers_panel.visible:
		workers_opened = true
	_refresh_ui()


func _cycle_speed() -> void:
	if game_speed < 1.5:
		game_speed = 2.0
	elif game_speed < 3.0:
		game_speed = 4.0
	else:
		game_speed = 1.0
	speed_btn.text = "Speed x%d" % int(game_speed)


func _new_pressed() -> void:
	if not new_armed:
		new_armed = true
		new_btn.text = "Tap again to restart"
		return
	_restart_game()


func _restart_game() -> void:
	var tree := get_tree()
	if tree.current_scene != null:
		tree.reload_current_scene()


func _toast(msg: String, seconds: float = 4.0) -> void:
	if not is_instance_valid(toast_label):
		return
	toast_label.text = msg
	toast_panel.visible = true
	toast_panel.modulate.a = 1.0
	toast_time = seconds


func _sum_jobs() -> int:
	var n := 0
	for r in RES_NAMES:
		n += int(jobs[r])
	return n


func _change_job(res: String, delta: int) -> void:
	var cur := int(jobs[res])
	if delta > 0:
		if _sum_jobs() >= survivors.size():
			_toast("Every villager already has a job. Reduce another resource first.")
			return
		jobs[res] = cur + 1
	else:
		if cur <= 0:
			return
		jobs[res] = cur - 1
	_assign_tasks()
	_refresh_ui()


func _clamp_jobs() -> void:
	while _sum_jobs() > survivors.size():
		var worst := ""
		var most := -1
		for r in RES_NAMES:
			if int(jobs[r]) > most:
				most = int(jobs[r])
				worst = r
		if worst == "" or most <= 0:
			break
		jobs[worst] = most - 1


func _refresh_ui() -> void:
	if not is_instance_valid(day_label):
		return
	day_label.text = "Day %d" % day
	var n := float(survivors.size())
	for r in RES_NAMES:
		var val: float = resources[r]
		var vl: Label = res_value_labels[r]
		vl.text = str(int(round(val)))
		var nl: Label = res_name_labels[r]
		if day > 1 or last_income[r] > 0.0:
			var net: float = float(last_income[r])
			if r == "Food":
				net -= n * FOOD_PER_VILLAGER
			elif r == "Water":
				net -= n * WATER_PER_VILLAGER
			nl.text = "%s %+d" % [r, int(round(net))]
			nl.add_theme_color_override("font_color", Color("#9fd36b") if net >= 0.0 else Color("#e8806e"))
		else:
			nl.text = r
	pop_label.text = "%d / %d" % [survivors.size(), _housing_capacity()]
	morale_bar.value = morale
	health_bar.value = health
	for bname in card_buttons:
		var btn: Button = card_buttons[bname]
		var def: Dictionary = BUILDINGS[bname]
		btn.modulate = Color(1, 1, 1, 1) if _missing_resource(def["cost"]) == "" else Color(1, 1, 1, 0.5)
	var free := 0
	for v in survivors:
		if v.task == "idle":
			free += 1
	for r in RES_NAMES:
		var cl: Label = job_count_labels[r]
		cl.text = str(int(jobs[r]))
	free_label.text = "Free villagers: %d" % free
	if workers_panel.visible:
		_refresh_villager_list()
	_check_goals()


func _refresh_villager_list() -> void:
	while villager_labels.size() > survivors.size():
		var extra: Label = villager_labels.pop_back()
		extra.queue_free()
	while villager_labels.size() < survivors.size():
		var l := _make_label("", 17)
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		villager_list.add_child(l)
		villager_labels.append(l)
	for i in range(survivors.size()):
		var v := survivors[i]
		villager_labels[i].text = "%s - %s\n%s" % [v.vname, v.skill, _villager_status(v)]
		villager_labels[i].add_theme_color_override("font_color", SKILL_COLORS[v.skill])


func _villager_status(v: Villager) -> String:
	match v.task:
		"build":
			if v.target != null:
				return "Building %s" % v.target.type
		"gather":
			var carrying := ""
			if v.carry_amt > 0.0:
				carrying = ", carrying %d %s" % [int(v.carry_amt), v.carry_res]
			return "Gathering %s%s" % [v.job, carrying]
	return "Resting at camp"


func _goal_done(key: String) -> bool:
	match key:
		"workers":
			return workers_opened
		"shelter":
			return _has_done("Shelter")
		"storehouse":
			return _has_done("Storehouse")
		"well":
			return _has_done("Well")
		"food":
			return _has_done("Farm") or _has_done("Olive Grove")
		"pop20":
			return survivors.size() >= 20
		"day30":
			return day >= 30
	return false


func _has_done(type: String) -> bool:
	for b in buildings:
		if b.done and b.type == type:
			return true
	return false


func _check_goals() -> void:
	while goal_index < GOALS.size() and _goal_done(str(GOALS[goal_index]["key"])):
		_toast("Goal complete: %s" % str(GOALS[goal_index]["text"]), 4.0)
		goal_index += 1
	if goal_index < GOALS.size():
		goal_label.text = str(GOALS[goal_index]["text"])
	else:
		goal_label.text = "All goals complete. More are coming."


# ---------------------------------------------------------------- villagers

func _create_survivors() -> void:
	for i in range(STARTING_POPULATION):
		_add_villager(NAMES[i], SKILLS[i % SKILLS.size()])


func _add_villager(vname: String, skill: String) -> Villager:
	var v := Villager.new()
	v.vname = vname
	v.skill = skill
	v.node = _make_villager_node(v, skill)
	var p := _random_point_around(camp_pos, 50.0, 140.0)
	v.node.position = p
	villager_root.add_child(v.node)
	v.goal = p
	v.phase = rng.randf() * TAU
	survivors.append(v)
	return v


func _make_villager_node(v: Villager, skill: String) -> Node3D:
	var root := Node3D.new()
	var body := MeshInstance3D.new()
	var capsule := CapsuleMesh.new()
	capsule.radius = 6.5
	capsule.height = 26.0
	body.mesh = capsule
	body.position.y = 13.0
	body.material_override = _mat(SKILL_COLORS[skill])
	root.add_child(body)
	_sphere(root, 5.5, Vector3(0, 31, 0), Color("#e0b88a"))
	v.carry_node = _box(root, Vector3(10, 10, 10), Vector3(0, 46, 0), Color("#ffffff"))
	v.carry_node.visible = false
	return root


func _random_point_around(center: Vector3, rmin: float, rmax: float) -> Vector3:
	var a := rng.randf() * TAU
	var r := rng.randf_range(rmin, rmax)
	var p := center + Vector3(cos(a) * r, 0.0, sin(a) * r)
	p.y = _height_at_world(p.x, p.z)
	return p


func _flat_dist(a: Vector3, b: Vector3) -> float:
	return Vector2(a.x - b.x, a.z - b.z).length()


func _count_builders(b: Building) -> int:
	var n := 0
	for v in survivors:
		if v.task == "build" and v.target == b:
			n += 1
	return n


func _count_job(res: String) -> int:
	var n := 0
	for v in survivors:
		if v.task == "gather" and v.job == res and not v.releasing:
			n += 1
	return n


func _nearest_idle(pos: Vector3) -> Villager:
	var best: Villager = null
	var best_d := INF
	for v in survivors:
		if v.task != "idle":
			continue
		var d := _flat_dist(v.node.position, pos)
		if d < best_d:
			best_d = d
			best = v
	return best


func _steal_gatherer(pos: Vector3) -> Villager:
	var best: Villager = null
	var best_d := INF
	for v in survivors:
		if v.task != "gather" or v.releasing or v.carry_amt > 0.0:
			continue
		var d := _flat_dist(v.node.position, pos)
		if d < best_d:
			best_d = d
			best = v
	if best != null:
		_set_idle(best)
	return best


func _pick_release(res: String) -> Villager:
	var fallback: Villager = null
	for v in survivors:
		if v.task != "gather" or v.job != res or v.releasing:
			continue
		if v.carry_amt <= 0.0:
			return v
		fallback = v
	return fallback


func _release(v: Villager) -> void:
	if v.carry_amt > 0.0:
		v.releasing = true
	else:
		_set_idle(v)


func _set_idle(v: Villager) -> void:
	v.task = "idle"
	v.job = ""
	v.state = ""
	v.target = null
	v.src = null
	v.releasing = false
	v.carry_amt = 0.0
	v.carry_res = ""
	v.carry_node.visible = false
	v.wait = 0.0
	v.goal = _random_point_around(camp_pos, 50.0, 190.0)


func _start_gather(v: Villager, res: String) -> void:
	v.task = "gather"
	v.job = res
	v.state = "seek"
	v.target = null
	v.src = null
	v.releasing = false
	v.wait = 0.0


func _send_build(v: Villager, b: Building) -> void:
	v.task = "build"
	v.job = ""
	v.state = ""
	v.src = null
	v.target = b
	v.wait = 0.0
	v.goal = _random_point_around(b.pos, 45.0, 70.0)


func _assign_tasks() -> void:
	for v in survivors:
		if v.task == "build":
			var bad := v.target == null or not buildings.has(v.target)
			if not bad:
				bad = v.target.done
			if bad:
				_set_idle(v)
	for b in buildings:
		if b.done:
			continue
		var need := 2 - _count_builders(b)
		while need > 0:
			var v := _nearest_idle(b.pos)
			if v == null:
				v = _steal_gatherer(b.pos)
			if v == null:
				break
			_send_build(v, b)
			need -= 1
	for r in RES_NAMES:
		var want := int(jobs[r])
		var have := _count_job(r)
		while have < want:
			var v2 := _nearest_idle(camp_pos)
			if v2 == null:
				break
			_start_gather(v2, r)
			have += 1
		while have > want:
			var w := _pick_release(r)
			if w == null:
				break
			_release(w)
			have -= 1


func _source_ok(s: Source) -> bool:
	return sources.has(s) and (s.infinite or s.amount >= 1.0)


func _source_users(s: Source, except: Villager) -> int:
	var n := 0
	for v in survivors:
		if v != except and v.task == "gather" and v.src == s and (v.state == "to_source" or v.state == "gathering"):
			n += 1
	return n


func _nearest_storage(pos: Vector3) -> Vector3:
	var best := camp_pos
	var best_d := _flat_dist(pos, camp_pos)
	for b in buildings:
		if b.done and b.type == "Storehouse":
			var d := _flat_dist(pos, b.pos)
			if d < best_d:
				best_d = d
				best = b.pos
	return best


func _pick_source(v: Villager) -> Source:
	var best: Source = null
	var best_score := INF
	for s in sources:
		if s.res != v.job or not _source_ok(s):
			continue
		if _source_users(s, v) >= s.slots:
			continue
		var store := _nearest_storage(s.pos)
		var walk := (_flat_dist(v.node.position, s.pos) + 2.0 * _flat_dist(s.pos, store)) / WALK_SPEED
		var score := (walk + s.gather_time) / s.yield_amt
		if score < best_score:
			best_score = score
			best = s
	return best


func _move(v: Villager, dt: float, bob: bool = false) -> bool:
	var pos := v.node.position
	var flat := Vector3(pos.x, 0.0, pos.z)
	var g := Vector3(v.goal.x, 0.0, v.goal.z)
	var dist := flat.distance_to(g)
	var hop := 0.0
	var arrived := dist <= 3.0
	if not arrived:
		var step := minf(dist, WALK_SPEED * dt)
		flat += (g - flat).normalized() * step
		v.phase += dt * 12.0
		hop = absf(sin(v.phase)) * 5.0
		v.node.rotation.y = atan2(g.x - flat.x, g.z - flat.z)
		arrived = flat.distance_to(g) <= 3.0
	elif bob:
		v.phase += dt * 14.0
		hop = absf(sin(v.phase)) * 6.0
	v.node.position = Vector3(flat.x, _height_at_world(flat.x, flat.z) + hop, flat.z)
	return arrived


func _update_villagers(dt: float) -> void:
	for v in survivors:
		match v.task:
			"idle":
				if _move(v, dt):
					v.wait -= dt
					if v.wait <= 0.0:
						v.goal = _random_point_around(camp_pos, 50.0, 190.0)
						v.wait = rng.randf_range(1.5, 4.5)
			"build":
				if _move(v, dt, true):
					v.wait -= dt
					if v.wait <= 0.0 and v.target != null:
						v.goal = _random_point_around(v.target.pos, 40.0, 70.0)
						v.wait = rng.randf_range(2.0, 5.0)
			"gather":
				_tick_gather(v, dt)


func _tick_gather(v: Villager, dt: float) -> void:
	match v.state:
		"seek":
			v.wait -= dt
			if v.wait > 0.0:
				_move(v, dt)
				return
			var s := _pick_source(v)
			if s == null:
				v.wait = 3.0
				v.goal = _random_point_around(camp_pos, 50.0, 120.0)
				_hint_no_source(v.job)
				return
			v.src = s
			v.state = "to_source"
			v.goal = s.pos + Vector3(rng.randf_range(-16.0, 16.0), 0.0, rng.randf_range(-16.0, 16.0))
		"to_source":
			if v.src == null or not _source_ok(v.src):
				v.state = "seek"
				v.wait = 0.0
				return
			if _move(v, dt):
				v.state = "gathering"
				v.timer = v.src.gather_time
		"gathering":
			if v.src == null or not _source_ok(v.src):
				v.state = "seek"
				v.wait = 0.0
				return
			_move(v, dt, true)
			v.timer -= dt
			if v.timer <= 0.0:
				_finish_gather(v)
		"to_store":
			if _move(v, dt):
				_deliver(v)
		_:
			v.state = "seek"


func _finish_gather(v: Villager) -> void:
	var s := v.src
	var take := s.yield_amt
	if not s.infinite:
		take = minf(take, s.amount)
		s.amount -= take
		_update_source_visual(s)
	if take < 1.0:
		v.state = "seek"
		v.wait = 0.0
		return
	v.carry_res = s.res
	v.carry_amt = take
	v.carry_node.material_override = _mat(RES_COLORS[s.res])
	v.carry_node.visible = true
	v.state = "to_store"
	var store := _nearest_storage(v.node.position)
	v.goal = store + Vector3(rng.randf_range(-14.0, 14.0), 0.0, rng.randf_range(-14.0, 14.0))


func _deliver(v: Villager) -> void:
	var res := v.carry_res
	var amt := v.carry_amt
	resources[res] = float(resources[res]) + amt
	income_today[res] = float(income_today[res]) + amt
	_pop_text(v.node.position, "+%d %s" % [int(amt), res], RES_COLORS[res])
	v.carry_amt = 0.0
	v.carry_res = ""
	v.carry_node.visible = false
	if v.releasing:
		_set_idle(v)
	else:
		v.state = "seek"
		v.wait = 0.0


func _hint_no_source(res: String) -> void:
	if int(no_source_day.get(res, -99)) == day:
		return
	no_source_day[res] = day
	var tip := ""
	match res:
		"Stone":
			tip = "Build a Quarry."
		"Scrap":
			tip = "Build a Workshop."
		"Food":
			tip = "Build a Farm or Olive Grove."
		"Water":
			tip = "Build a Well."
		"Wood":
			tip = "Trees regrow slowly. Wait or reassign workers."
	_toast("No %s left to gather nearby. %s" % [res, tip], 5.0)


func _pop_text(pos: Vector3, text: String, color: Color) -> void:
	var l := Label3D.new()
	l.text = text
	l.font_size = 36
	l.pixel_size = 0.9
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.no_depth_test = true
	l.outline_size = 10
	l.modulate = color.lightened(0.25)
	add_child(l)
	l.position = pos + Vector3(0, 60, 0)
	var tw := create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position:y", l.position.y + 60.0, 1.2)
	tw.tween_property(l, "modulate:a", 0.0, 1.2)
	tw.chain().tween_callback(l.queue_free)


# ---------------------------------------------------------------- buildings

func _missing_resource(cost: Dictionary) -> String:
	for r in cost:
		if float(resources[r]) < float(cost[r]):
			return r
	return ""


func _cell_problem(cell: Vector2i) -> String:
	if not _is_land(cell.x, cell.y):
		return "That spot is in the sea or off the map."
	if Vector2(cell - CAMP_CELL).length() < 1.6:
		return "Too close to the camp fire."
	for b in buildings:
		if b.cell == cell:
			return "That spot is already occupied."
	var v := _grid_vertex(cell.x, cell.y)
	for s in sources:
		if s.building == null and _flat_dist(s.pos, v) < TILE_SIZE * 1.3:
			return "A resource point is here. Build beside it, not on it."
	if v.y > 330.0:
		return "Too high on the ridge."
	var rng_h := _footing_range(v.x, v.z)
	if rng_h.y - rng_h.x > 30.0:
		return "The ground is too steep here."
	return ""


func _select_building(bname: String) -> void:
	if menu_open or game_over:
		return
	var def: Dictionary = BUILDINGS[bname]
	var missing := _missing_resource(def["cost"])
	if missing != "":
		_toast("Not enough %s to build a %s." % [missing, bname])
		return
	_close_inspect()
	selected_building = bname
	cards_row.visible = false
	confirm_row.visible = true
	var size := get_viewport().get_visible_rect().size
	var cell := CAMP_CELL + Vector2i(2, 2)
	var hit: Variant = _ray_to_terrain(Vector2(size.x * 0.5, size.y * 0.45))
	if hit != null:
		var hp: Vector3 = hit
		cell = _cell_from_point(hp)
	_set_ghost_cell(_nearest_valid_cell(cell))


func _nearest_valid_cell(start: Vector2i) -> Vector2i:
	for radius in range(0, 8):
		for dx in range(-radius, radius + 1):
			for dz in range(-radius, radius + 1):
				if maxi(absi(dx), absi(dz)) != radius:
					continue
				var c := start + Vector2i(dx, dz)
				if _cell_problem(c) == "":
					return c
	return start


func _set_ghost_cell(cell: Vector2i) -> void:
	ghost_cell = cell
	var problem := _cell_problem(cell)
	ghost_valid = problem == ""
	var v := _grid_vertex(cell.x, cell.y)
	ghost.position = Vector3(v.x, _footing_range(v.x, v.z).y, v.z)
	ghost.visible = true
	ghost_mat.albedo_color = Color(0.3, 0.9, 0.3, 0.55) if ghost_valid else Color(0.95, 0.3, 0.3, 0.55)
	confirm_btn.disabled = not ghost_valid
	var def: Dictionary = BUILDINGS[selected_building]
	var head := "%s  (%s)\n%s" % [selected_building, _cost_long(def["cost"]), def["description"]]
	info_label.text = head + ("\nTap the land to move the marker, then press Build here." if ghost_valid else "\n" + problem)


func _cancel_placement() -> void:
	selected_building = ""
	ghost.visible = false
	if inspected == null:
		cards_row.visible = true
		confirm_row.visible = false
		inspect_row.visible = false
		info_label.text = "Choose a building to construct"


func _confirm_build() -> void:
	if selected_building == "" or not ghost_valid:
		return
	var def: Dictionary = BUILDINGS[selected_building]
	var cost: Dictionary = def["cost"]
	var missing := _missing_resource(cost)
	if missing != "":
		_toast("Not enough %s." % missing)
		return
	for r in cost:
		resources[r] = float(resources[r]) - float(cost[r])
	var bname := selected_building
	_spawn_building(bname, ghost_cell, 0.0, false)
	_cancel_placement()
	_assign_tasks()
	_refresh_ui()
	_toast("%s foundation laid. Builders are on their way." % bname)


func _spawn_building(type: String, cell: Vector2i, progress: float, done: bool) -> Building:
	var b := Building.new()
	b.type = type
	b.cell = cell
	var v := _grid_vertex(cell.x, cell.y)
	b.pos = Vector3(v.x, _footing_range(v.x, v.z).y, v.z)
	b.progress = progress
	b.done = done
	b.node = Node3D.new()
	b.node.position = b.pos
	building_root.add_child(b.node)
	_box(b.node, Vector3(62, 40, 58), Vector3(0, -18, 0), Color("#d8caa4"), true)
	b.model = _make_building_model(type)
	b.model.position.y = 2.0
	b.node.add_child(b.model)
	if not done:
		b.model.scale = Vector3(1.0, lerpf(0.12, 1.0, progress), 1.0)
		b.scaffold = _make_scaffold()
		b.node.add_child(b.scaffold)
		b.label = Label3D.new()
		b.label.font_size = 40
		b.label.pixel_size = 1.0
		b.label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		b.label.no_depth_test = true
		b.label.outline_size = 12
		b.label.modulate = Color("#fff3c4")
		b.label.position = Vector3(0, 95, 0)
		b.node.add_child(b.label)
	buildings.append(b)
	if done:
		_add_building_source(b)
	return b


func _update_construction(dt: float) -> void:
	for b in buildings:
		if b.done:
			continue
		var rate := 0.0
		for v in survivors:
			if v.task == "build" and v.target == b and _flat_dist(v.node.position, b.pos) < 110.0:
				rate += 1.5 if v.skill == "Construction" else 1.0
		var def: Dictionary = BUILDINGS[b.type]
		b.progress = minf(1.0, b.progress + rate * dt / float(def["time"]))
		b.model.scale = Vector3(1.0, lerpf(0.12, 1.0, b.progress), 1.0)
		if rate > 0.0:
			b.label.text = "%s  %d%%" % [b.type, int(b.progress * 100.0)]
		else:
			b.label.text = "%s  waiting for builders" % b.type
		if b.progress >= 1.0:
			_complete_building(b)


func _complete_building(b: Building) -> void:
	b.done = true
	b.progress = 1.0
	if is_instance_valid(b.scaffold):
		b.scaffold.queue_free()
	if is_instance_valid(b.label):
		b.label.queue_free()
	b.model.scale = Vector3.ONE
	var tw := create_tween()
	tw.tween_property(b.model, "scale", Vector3.ONE, 0.35).from(Vector3(1.12, 1.12, 1.12))
	_add_building_source(b)
	_assign_tasks()
	_refresh_ui()
	_toast("%s completed!" % b.type)


func _building_status(b: Building) -> String:
	if not b.done:
		return "%s - under construction (%d%%)" % [b.type, int(b.progress * 100.0)]
	var def: Dictionary = BUILDINGS[b.type]
	var g: Dictionary = def["gather"]
	if not g.is_empty():
		var users := 0
		for s in sources:
			if s.building == b:
				users = _source_users(s, null)
		return "%s - completed. %s: %d/%d workers" % [b.type, g["res"], users, int(g["slots"])]
	return "%s - completed. %s" % [b.type, def["description"]]


func _inspect_building(b: Building) -> void:
	if selected_building != "":
		return
	inspected = b
	demolish_armed = false
	demolish_btn.text = "Demolish (refund 50%)"
	cards_row.visible = false
	confirm_row.visible = false
	inspect_row.visible = true
	info_label.text = _building_status(b)


func _close_inspect() -> void:
	inspected = null
	demolish_armed = false
	if selected_building == "":
		inspect_row.visible = false
		confirm_row.visible = false
		cards_row.visible = true
		info_label.text = "Choose a building to construct"


func _demolish_pressed() -> void:
	if inspected == null:
		return
	var b := inspected
	var def: Dictionary = BUILDINGS[b.type]
	if b.done and int(def["housing"]) > 0 and survivors.size() > _housing_capacity() - int(def["housing"]):
		_toast("Villagers still live in this %s." % b.type)
		return
	if not demolish_armed:
		demolish_armed = true
		demolish_btn.text = "Tap again to confirm"
		return
	var cost: Dictionary = def["cost"]
	for r in cost:
		resources[r] = float(resources[r]) + floorf(float(cost[r]) * 0.5)
	for i in range(sources.size() - 1, -1, -1):
		if sources[i].building == b:
			sources.remove_at(i)
	for v in survivors:
		if v.src != null and not sources.has(v.src):
			v.src = null
			if v.task == "gather" and v.state != "to_store":
				v.state = "seek"
				v.wait = 0.0
	buildings.erase(b)
	b.node.queue_free()
	_toast("%s demolished. Half the materials were recovered." % b.type)
	_close_inspect()
	_assign_tasks()
	_refresh_ui()


# ---------------------------------------------------------------- simulation

func _housing_capacity() -> int:
	var capacity := BASE_HOUSING
	for b in buildings:
		if b.done:
			var def: Dictionary = BUILDINGS[b.type]
			capacity += int(def["housing"])
	return capacity


func _advance_day() -> void:
	day += 1
	var n := float(survivors.size())
	resources["Food"] = float(resources["Food"]) - n * FOOD_PER_VILLAGER
	resources["Water"] = float(resources["Water"]) - n * WATER_PER_VILLAGER
	var shortage := float(resources["Food"]) < 0.0 or float(resources["Water"]) < 0.0
	for r in RES_NAMES:
		resources[r] = maxf(0.0, float(resources[r]))
	last_income = income_today.duplicate()
	for r in RES_NAMES:
		income_today[r] = 0.0
	for s in sources:
		if s.regen > 0.0 and not s.infinite:
			s.amount = minf(s.max_amount, s.amount + s.max_amount * s.regen)
			_update_source_visual(s)
	var medics := 0
	for v in survivors:
		if v.skill == "Medicine":
			medics += 1
	if shortage:
		health = maxf(0.0, health - 7.0)
		morale = maxf(0.0, morale - 8.0)
		_toast("Shortage! Put more villagers on Food and Water.", 5.0)
		if health <= 0.0:
			_remove_villager()
			_remove_villager()
		elif health <= 25.0:
			_remove_villager()
	else:
		morale = minf(100.0, morale + 1.0)
		health = minf(100.0, health + 2.0 + float(medics))
		_toast("Day %d begins." % day, 2.0)
	if survivors.is_empty():
		_trigger_game_over()
		return
	if day % 4 == 0 and _housing_capacity() > survivors.size() and health > 40.0 and morale > 45.0 and not shortage:
		_add_villager(NAMES[survivors.size() % NAMES.size()], SKILLS[rng.randi() % SKILLS.size()])
		_toast("A newcomer joined. Give them a job in Workers.", 4.0)
	peak_pop = maxi(peak_pop, survivors.size())
	_assign_tasks()
	_refresh_ui()


func _remove_villager() -> void:
	if survivors.is_empty():
		return
	var v: Villager = survivors[survivors.size() - 1]
	survivors.erase(v)
	v.node.queue_free()
	_clamp_jobs()
	_toast("A villager left the settlement.", 5.0)


func _trigger_game_over() -> void:
	game_over = true
	var built := 0
	for b in buildings:
		if b.done:
			built += 1
	over_label.text = "Your people lasted %d days.\nBuildings completed: %d.   Peak population: %d." % [day, built, peak_pop]
	over_layer.visible = true


func _process(delta: float) -> void:
	if toast_time > 0.0:
		toast_time -= delta
		if toast_time <= 0.0:
			toast_panel.visible = false
		elif toast_time < 0.7:
			toast_panel.modulate.a = toast_time / 0.7
	if menu_open or game_over:
		return
	var dt := 0.0 if paused else delta * game_speed
	if dt > 0.0:
		day_timer += dt
		if day_timer >= DAY_LENGTH:
			day_timer -= DAY_LENGTH
			_advance_day()
			if game_over:
				return
		_update_construction(dt)
		_update_villagers(dt)
		assign_timer += delta
		if assign_timer >= 1.0:
			assign_timer = 0.0
			_assign_tasks()
		autosave_timer += delta
		if autosave_timer >= AUTOSAVE_EVERY:
			autosave_timer = 0.0
			_write_save(AUTOSAVE_PATH, true)
	ui_timer += delta
	if ui_timer >= 0.5:
		ui_timer = 0.0
		_refresh_ui()
	if is_instance_valid(day_bar):
		day_bar.value = day_timer / DAY_LENGTH * 100.0


# ---------------------------------------------------------------- input

func _unhandled_input(event: InputEvent) -> void:
	if menu_open or game_over:
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			touches[event.index] = event.position
		else:
			touches.erase(event.index)
		if touches.size() >= 2:
			pinch_last = _pinch_distance()
			drag_moved = true
		return
	if event is InputEventScreenDrag:
		touches[event.index] = event.position
		if touches.size() >= 2:
			var d := _pinch_distance()
			if pinch_last > 0.0 and d > 0.0:
				_zoom(pinch_last / d)
			pinch_last = d
		return
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
			_zoom(0.88)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
			_zoom(1.12)
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			right_drag = event.pressed
		elif event.button_index == MOUSE_BUTTON_LEFT:
			if event.pressed:
				drag_active = true
				drag_moved = false
				press_pos = event.position
			else:
				if drag_active and not drag_moved and touches.size() < 2:
					_on_tap(event.position)
				drag_active = false
	elif event is InputEventMouseMotion:
		if right_drag:
			_pan_camera(event.relative)
		elif drag_active and touches.size() < 2:
			if event.position.distance_to(press_pos) > 14.0:
				drag_moved = true
			if drag_moved:
				_pan_camera(event.relative)


func _pinch_distance() -> float:
	var pts: Array = touches.values()
	if pts.size() < 2:
		return 0.0
	var a: Vector2 = pts[0]
	var b: Vector2 = pts[1]
	return a.distance_to(b)


func _zoom(factor: float) -> void:
	camera.size = clampf(camera.size * factor, 350.0, 3200.0)


func _pan_camera(delta: Vector2) -> void:
	var vh := get_viewport().get_visible_rect().size.y
	var per_px := camera.size / vh
	var cb := camera.global_transform.basis
	var right := Vector3(cb.x.x, 0.0, cb.x.z).normalized()
	var fwd := Vector3(-cb.z.x, 0.0, -cb.z.z).normalized()
	var ground_scale := CAM_OFFSET.length() / CAM_OFFSET.y
	camera_target += (-right * delta.x + fwd * delta.y * ground_scale) * per_px
	camera_target.x = clampf(camera_target.x, -1400.0, 1500.0)
	camera_target.z = clampf(camera_target.z, -1700.0, 1700.0)
	_update_camera()


func _ray_to_terrain(screen_pos: Vector2) -> Variant:
	var origin := camera.project_ray_origin(screen_pos)
	var dir := camera.project_ray_normal(screen_pos)
	var prev_t := 0.0
	var t := 0.0
	while t < 9000.0:
		var p := origin + dir * t
		if p.y <= _height_at_world(p.x, p.z):
			var lo := prev_t
			var hi := t
			for i in range(12):
				var mid := (lo + hi) * 0.5
				var q := origin + dir * mid
				if q.y <= _height_at_world(q.x, q.z):
					hi = mid
				else:
					lo = mid
			return origin + dir * hi
		prev_t = t
		t += 20.0
	return null


func _screen_dist(pos: Vector2, world: Vector3) -> float:
	return camera.unproject_position(world).distance_to(pos)


func _on_tap(pos: Vector2) -> void:
	var hit: Variant = _ray_to_terrain(pos)
	if hit == null:
		return
	var hp: Vector3 = hit
	var cell := _cell_from_point(hp)
	if selected_building != "":
		_set_ghost_cell(cell)
		return
	var best_v: Villager = null
	var best_d := 46.0
	for v in survivors:
		var d := _screen_dist(pos, v.node.position + Vector3(0, 20, 0))
		if d < best_d:
			best_d = d
			best_v = v
	if best_v != null:
		_toast("%s (%s): %s" % [best_v.vname, best_v.skill, _villager_status(best_v)], 3.5)
		return
	var best_s: Source = null
	best_d = 56.0
	for s in sources:
		if s.building != null or s.node == null:
			continue
		var d2 := _screen_dist(pos, s.pos + Vector3(0, 12, 0))
		if d2 < best_d:
			best_d = d2
			best_s = s
	if best_s != null:
		var left := "endless" if best_s.infinite else "%d left" % int(best_s.amount)
		_toast("%s (%s): %s" % [best_s.label, best_s.res, left], 3.5)
		return
	for b in buildings:
		if b.cell == cell:
			_inspect_building(b)
			return
	_close_inspect()


# ---------------------------------------------------------------- save / load

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED and is_instance_valid(day_label) and not game_over:
		_write_save(AUTOSAVE_PATH, true)


func _save_game() -> void:
	_write_save(SAVE_PATH, false)


func _write_save(path: String, silent: bool) -> void:
	var blist: Array = []
	for b in buildings:
		blist.append({"type": b.type, "cell": [b.cell.x, b.cell.y], "progress": b.progress, "done": b.done})
	var vlist: Array = []
	for v in survivors:
		vlist.append([v.vname, v.skill])
	var amounts: Array = []
	for s in sources:
		if s.building == null:
			amounts.append(s.amount)
	var data := {
		"version": SAVE_VERSION, "region": "Haifa", "resources": resources, "jobs": jobs, "day": day,
		"morale": morale, "health": health, "goal": goal_index, "peak": peak_pop,
		"buildings": blist, "villagers": vlist, "sources": amounts
	}
	var file := FileAccess.open(path, FileAccess.WRITE)
	if file == null:
		if not silent:
			_toast("Could not write the save file.")
		return
	file.store_string(JSON.stringify(data))
	if not silent:
		_toast("Settlement saved on this device.")


func _load_game(path: String) -> void:
	if not FileAccess.file_exists(path):
		_toast("No saved settlement found there yet.")
		return
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null:
		_toast("Could not read the save file.")
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY:
		_toast("Save file is invalid.")
		return
	var d: Dictionary = parsed
	if str(d.get("region", "")) != "Haifa" or int(d.get("version", 0)) < SAVE_VERSION:
		_toast("That save is from an older version and cannot be loaded.")
		return
	_cancel_placement()
	_close_inspect()
	for b in buildings:
		b.node.queue_free()
	buildings.clear()
	for i in range(sources.size() - 1, -1, -1):
		if sources[i].building != null:
			sources.remove_at(i)
	for v in survivors:
		v.node.queue_free()
	survivors.clear()
	var saved_res: Dictionary = d.get("resources", {})
	for r in RES_NAMES:
		resources[r] = float(saved_res.get(r, resources[r]))
	var saved_jobs: Dictionary = d.get("jobs", {})
	for r in RES_NAMES:
		jobs[r] = int(saved_jobs.get(r, 0))
	day = int(d.get("day", day))
	morale = float(d.get("morale", morale))
	health = float(d.get("health", health))
	goal_index = clampi(int(d.get("goal", 0)), 0, GOALS.size())
	peak_pop = int(d.get("peak", STARTING_POPULATION))
	day_timer = 0.0
	var amounts: Array = d.get("sources", [])
	var idx := 0
	for s in sources:
		if s.building == null:
			if idx < amounts.size():
				s.amount = float(amounts[idx])
				_update_source_visual(s)
			idx += 1
	var blist: Array = d.get("buildings", [])
	for e in blist:
		if typeof(e) != TYPE_DICTIONARY:
			continue
		var ed: Dictionary = e
		var t := str(ed.get("type", ""))
		if not BUILDINGS.has(t):
			continue
		var c: Array = ed.get("cell", [0, 0])
		_spawn_building(t, Vector2i(int(c[0]), int(c[1])), float(ed.get("progress", 1.0)), bool(ed.get("done", true)))
	var vlist: Array = d.get("villagers", [])
	for e in vlist:
		if typeof(e) == TYPE_ARRAY and e.size() >= 2 and SKILL_COLORS.has(str(e[1])):
			_add_villager(str(e[0]), str(e[1]))
	if survivors.is_empty():
		for i in range(STARTING_POPULATION):
			_add_villager(NAMES[i], SKILLS[i % SKILLS.size()])
	_clamp_jobs()
	game_over = false
	over_layer.visible = false
	_assign_tasks()
	_refresh_ui()
	_close_menu()
	_toast("Settlement loaded.")
